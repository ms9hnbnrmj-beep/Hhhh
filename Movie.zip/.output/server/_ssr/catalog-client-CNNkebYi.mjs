//#region node_modules/.nitro/vite/services/ssr/assets/catalog-client-CNNkebYi.js
async function getCatalog(params) {
	const search = new URLSearchParams();
	Object.entries(params).forEach(([key, value]) => {
		if (value !== void 0 && value !== "") search.set(key, String(value));
	});
	const response = await fetch(`/api/catalog?${search.toString()}`);
	if (!response.ok) {
		const body = await response.json().catch(() => null);
		throw new Error(body?.error || "تعذر تحميل الكتالوج الآن.");
	}
	return await response.json();
}
async function getCatalogDetails(id, media) {
	const search = new URLSearchParams({
		mode: "details",
		id,
		media
	});
	const response = await fetch(`/api/catalog?${search.toString()}`);
	if (!response.ok) {
		const body = await response.json().catch(() => null);
		throw new Error(body?.error || "تعذر تحميل تفاصيل العمل.");
	}
	return await response.json();
}
async function getWatchlist(profileId) {
	const response = await fetch(`/api/watchlist?profileId=${encodeURIComponent(profileId)}`);
	if (!response.ok) throw new Error("خدمة حفظ القائمة غير متاحة الآن.");
	return (await response.json()).items ?? [];
}
async function putWatchlist(profileId, items) {
	if (!(await fetch("/api/watchlist", {
		method: "PUT",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			profileId,
			items
		})
	})).ok) throw new Error("تعذر مزامنة قائمة المشاهدة.");
}
function parseMediaId(value) {
	let decoded = value;
	try {
		decoded = decodeURIComponent(value);
	} catch {}
	const match = /^(movie|tv|anime):(.+)$/.exec(decoded);
	if (!match?.[1] || !match[2]) return null;
	return {
		media: match[1],
		id: match[2]
	};
}
//#endregion
export { putWatchlist as a, parseMediaId as i, getCatalogDetails as n, getWatchlist as r, getCatalog as t };
