//#region node_modules/.nitro/vite/services/ssr/assets/empty-plugin-adapters-Dybcz1Oh.js
var pluginSerializationAdapters = [];
var hasPluginAdapters = false;
//#endregion
export { hasPluginAdapters, pluginSerializationAdapters };
