import { c as lazyRouteComponent, l as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/movie._id--LExS6rF.js
var $$splitComponentImporter = () => import("./movie._id-uc1-g3xo.mjs");
var Route = createFileRoute("/movie/$id")({
	head: ({ params }) => ({ meta: [{ title: `تفاصيل العنوان — T3B TV` }, {
		name: "description",
		content: `اكتشف ملخص ومعلومات العنوان ${params.id} على T3B TV.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
