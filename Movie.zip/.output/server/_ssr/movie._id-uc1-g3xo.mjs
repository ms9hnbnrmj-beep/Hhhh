import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { d as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./movie._id--LExS6rF.mjs";
import { a as putWatchlist, i as parseMediaId, n as getCatalogDetails, r as getWatchlist } from "./catalog-client-CNNkebYi.mjs";
import { _ as ArrowRight, d as Clapperboard, f as ChevronRight, g as Bookmark, h as CalendarDays, l as Film, n as Tv, r as Star, s as Play, u as ExternalLink } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/movie._id-uc1-g3xo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MoviePage() {
	const { id: routeId } = Route.useParams();
	const parsed = parseMediaId(routeId);
	const { data, isLoading, error } = useQuery({
		queryKey: ["details", routeId],
		queryFn: () => getCatalogDetails(parsed.id, parsed.media),
		enabled: Boolean(parsed),
		staleTime: 1800 * 1e3
	});
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [profileId, setProfileId] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!data) return;
		const profile = window.localStorage.getItem("t3b-profile-id") || window.crypto.randomUUID();
		window.localStorage.setItem("t3b-profile-id", profile);
		setProfileId(profile);
		const id = `${data.mediaType}:${data.id}`;
		const local = window.localStorage.getItem("t3b-watchlist");
		try {
			setSaved(JSON.parse(local || "[]").some((item) => `${item.mediaType}:${item.id}` === id));
		} catch {
			setSaved(false);
		}
		getWatchlist(profile).then((items) => setSaved(items.some((item) => `${item.mediaType}:${item.id}` === id))).catch(() => void 0);
	}, [data]);
	function toggleSaved() {
		if (!data) return;
		const item = {
			id: data.id,
			title: data.title,
			overview: data.overview,
			poster: data.poster,
			backdrop: data.backdrop,
			mediaType: data.mediaType,
			year: data.year,
			rating: data.rating,
			genres: data.genres,
			...data.seasonCount !== void 0 ? { seasonCount: data.seasonCount } : {}
		};
		let list = [];
		try {
			list = JSON.parse(window.localStorage.getItem("t3b-watchlist") || "[]");
		} catch {
			list = [];
		}
		const hasItem = list.some((entry) => entry.id === item.id && entry.mediaType === item.mediaType);
		const next = hasItem ? list.filter((entry) => !(entry.id === item.id && entry.mediaType === item.mediaType)) : [item, ...list].slice(0, 250);
		setSaved(!hasItem);
		window.localStorage.setItem("t3b-watchlist", JSON.stringify(next));
		if (profileId) putWatchlist(profileId, next).catch(() => void 0);
	}
	const mediaLabel = data?.mediaType === "tv" ? "مسلسل" : data?.mediaType === "anime" ? "أنمي" : "فيلم";
	if (!parsed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: "rtl",
		className: "detail-page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "detail-empty",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "رابط العنوان غير صالح" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "العودة إلى الصفحة الرئيسية"
			})]
		})
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: "rtl",
		className: "detail-page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "detail-loading",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "detail-spinner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "نجهّز تفاصيل العمل..." })]
		})
	});
	if (error || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: "rtl",
		className: "detail-page",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "detail-empty",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 30 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "تعذر تحميل التفاصيل" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "تحقق من الاتصال بمصدر البيانات ثم حاول مجددًا بعد قليل." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "العودة إلى المكتبة"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "detail-page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "detail-backdrop",
				style: data.backdrop ? { backgroundImage: `url("${data.backdrop}")` } : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "detail-overlay" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "detail-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "brand-mark",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							size: 14,
							fill: "currentColor",
							strokeWidth: 0
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "brand-word",
						children: ["T3B ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "TV" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "back-link",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 18 }), " العودة إلى الاستكشاف"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "detail-content",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "detail-poster",
					children: data.poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: data.poster,
						alt: `ملصق ${data.title}`
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "poster-fallback",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { size: 40 })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "detail-info",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "detail-overline",
							children: [
								mediaLabel,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
								" T3B اختيار المحررين"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: data.title }),
						data.releaseDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "detail-original-date",
							children: ["تاريخ الإصدار: ", data.releaseDate]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "detail-facts",
							children: [
								data.year && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { size: 15 }),
									" ",
									data.year
								] }),
								data.rating !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "detail-rating",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
											size: 15,
											fill: "currentColor"
										}),
										" ",
										data.rating.toFixed(1),
										" / 10"
									]
								}),
								data.runtime && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [data.runtime, " دقيقة"] }),
								data.seasonCount !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { size: 15 }),
									" ",
									data.seasonCount,
									" ",
									data.mediaType === "anime" && !data.id.startsWith("tmdb-") ? "حلقة" : "موسم"
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "detail-genres",
							children: data.genres.map((genre) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: genre }, genre))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "عن العمل" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "detail-overview",
							children: data.overview || "لا يتوفر ملخص لهذا العنوان حاليًا."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "detail-actions",
							children: [
								data.trailerKey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "button-primary",
									href: `https://www.youtube.com/watch?v=${encodeURIComponent(data.trailerKey)}`,
									target: "_blank",
									rel: "noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										size: 17,
										fill: "currentColor"
									}), " الإعلان الرسمي"]
								}),
								data.watchUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "button-ghost",
									href: data.watchUrl,
									target: "_blank",
									rel: "noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { size: 17 }), " أماكن المشاهدة الرسمية"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: saved ? "button-ghost saved-action" : "button-ghost",
									onClick: toggleSaved,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { size: 17 }),
										" ",
										saved ? "أُضيف إلى قائمتي" : "أضف إلى قائمتي"
									]
								})
							]
						}),
						data.seasons && data.seasons.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "season-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "المواسم" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: data.seasons.map((season, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [season.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: season.episodeCount ? `${season.episodeCount} حلقة` : "" })] }, `${season.name}-${index}`)) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "legal-note",
							children: "تُعرض معلومات العنوان والإعلان وروابط الوصول إلى مزودي المشاهدة الرسميين. لا يستضيف T3B TV ملفات الأفلام أو الحلقات."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "detail-footer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "detail-footer-link",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 }), " استكشف المزيد"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الملصقات والبيانات: TMDB • معلومات الأنمي: Jikan" })]
			})
		]
	});
}
//#endregion
export { MoviePage as component };
