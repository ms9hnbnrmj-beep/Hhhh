import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, n as QueryClientProvider, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as lazyRouteComponent, d as Link, f as useRouter, i as HeadContent, l as createFileRoute, o as createRouter, r as Scripts, s as Outlet, u as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$4 } from "./movie._id--LExS6rF.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as require_promise } from "../_libs/mysql2+[...].mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/router-NdWCoARd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_promise = require_promise();
var styles_default = "/assets/styles-Bdp-fi9p.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$3 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "T3B TV" },
			{
				name: "description",
				content: "T3B TV — اكتشف الأفلام والمسلسلات والأنمي من حول العالم."
			},
			{
				name: "author",
				content: "T3B TV"
			},
			{
				property: "og:title",
				content: "T3B TV"
			},
			{
				property: "og:description",
				content: "اكتشف الأفلام والمسلسلات والأنمي من حول العالم."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Cairo:wght@400;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$3.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter = () => import("./routes-DBab1lNe.mjs");
var Route$2 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "T3B TV — اكتشف حكايتك القادمة" },
		{
			name: "description",
			content: "اكتشف أفلامًا ومسلسلات وأنمي من مختلف أنحاء العالم، وابحث حسب النوع والسنة والتقييم."
		},
		{
			property: "og:title",
			content: "T3B TV — اكتشف حكايتك القادمة"
		},
		{
			property: "og:description",
			content: "كتالوج عالمي للأفلام والمسلسلات والأنمي مع صور أصلية وتفاصيل محدثة."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var TMDB_BASE = "https://api.themoviedb.org/3";
var TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";
var JIKAN_BASE = "https://api.jikan.moe/v4";
var MAX_PAGE = 500;
var ApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.status = status;
		this.name = "ApiError";
	}
};
var genreNames = {
	"12": "مغامرة",
	"14": "فانتازيا",
	"16": "رسوم متحركة",
	"18": "دراما",
	"27": "رعب",
	"28": "أكشن",
	"35": "كوميديا",
	"36": "تاريخ",
	"37": "ويسترن",
	"53": "إثارة",
	"80": "جريمة",
	"99": "وثائقي",
	"878": "خيال علمي",
	"9648": "غموض",
	"10402": "موسيقى",
	"10749": "رومانسي",
	"10751": "عائلي",
	"10752": "حرب",
	"10759": "أكشن ومغامرة",
	"10762": "أطفال",
	"10763": "أخبار",
	"10764": "واقعي",
	"10765": "خيال علمي وفانتازيا",
	"10766": "دراما نهارية",
	"10767": "حواري",
	"10768": "حرب وسياسة",
	"10770": "فيلم تلفزيوني"
};
var animeGenreNames = {
	"1": "أكشن",
	"2": "مغامرة",
	"4": "كوميديا",
	"7": "غموض",
	"8": "دراما",
	"10": "فانتازيا",
	"14": "رعب",
	"22": "رومانسي",
	"24": "خيال علمي",
	"36": "حياة يومية",
	"41": "تشويق"
};
var tmdbToAnimeGenre = {
	"28": "1",
	"12": "2",
	"35": "4",
	"9648": "7",
	"18": "8",
	"14": "10",
	"27": "14",
	"10749": "22",
	"878": "24",
	"53": "41"
};
function record(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function text(value) {
	return typeof value === "string" ? value : "";
}
function finiteNumber(value) {
	return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function animeRuntimeMinutes(value) {
	const direct = finiteNumber(value);
	if (direct !== null) return direct;
	const duration = text(value);
	const hours = Number(duration.match(/(\d+)\s*hour/i)?.[1] ?? 0);
	const minutes = Number(duration.match(/(\d+)\s*min/i)?.[1] ?? 0);
	const totalMinutes = hours * 60 + minutes;
	return totalMinutes > 0 ? totalMinutes : null;
}
function list(value) {
	return Array.isArray(value) ? value : [];
}
function imageUrl(value, size) {
	const path = text(value);
	return path.startsWith("/") ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}
function yearFrom(value) {
	return (typeof value === "number" ? String(value) : text(value)).match(/^(\d{4})/)?.[1] ?? null;
}
function tmdbGenres(value) {
	return list(value).map((entry) => {
		const genre = record(entry);
		return text(genre.name) || genreNames[String(genre.id ?? "")] || "";
	}).filter(Boolean);
}
function tmdbGenreIds(value) {
	return list(value).map((id) => genreNames[String(id)] ?? "").filter(Boolean);
}
function normalizeTmdb(value, forcedType) {
	const item = record(value);
	const mediaType = forcedType ?? (item.media_type === "tv" ? "tv" : item.media_type === "movie" ? "movie" : "movie");
	const title = text(item.title) || text(item.name) || text(item.original_title) || text(item.original_name);
	const seasonCount = finiteNumber(item.number_of_seasons);
	return {
		id: String(item.id ?? ""),
		title,
		overview: text(item.overview),
		poster: imageUrl(item.poster_path, "w500"),
		backdrop: imageUrl(item.backdrop_path, "w1280"),
		mediaType,
		year: yearFrom(item.release_date ?? item.first_air_date),
		rating: finiteNumber(item.vote_average),
		genres: list(item.genres).length > 0 ? tmdbGenres(item.genres) : tmdbGenreIds(item.genre_ids),
		...(mediaType === "tv" || mediaType === "anime") && seasonCount !== null ? { seasonCount } : {}
	};
}
function normalizeAnime(value) {
	const item = record(value);
	const jpg = record(record(item.images).jpg);
	const trailerImages = record(record(item.trailer).images);
	const title = text(item.title) || text(item.title_english) || text(item.title_japanese);
	const genres = [
		...list(item.genres),
		...list(item.themes),
		...list(item.demographics)
	].map((entry) => {
		const genre = record(entry);
		return animeGenreNames[String(genre.mal_id ?? "")] ?? text(genre.name);
	}).filter(Boolean);
	const image = text(record(jpg.large_image_url).url) || text(jpg.large_image_url);
	const backdrop = text(trailerImages.maximum_image_url);
	const aired = record(item.aired);
	const score = finiteNumber(item.score);
	const episodes = finiteNumber(item.episodes);
	return {
		id: String(item.mal_id ?? ""),
		title,
		overview: text(item.synopsis),
		poster: image || null,
		backdrop: backdrop || null,
		mediaType: "anime",
		year: yearFrom(item.year ?? record(aired.from).year),
		rating: score,
		genres: [...new Set(genres)],
		...episodes !== null ? { seasonCount: episodes } : {}
	};
}
function parsePage(raw) {
	if (raw === null || raw === "") return 1;
	const page = Number(raw);
	if (!Number.isInteger(page) || page < 1 || page > MAX_PAGE) throw new ApiError(`page must be an integer between 1 and ${MAX_PAGE}.`, 400);
	return page;
}
function parseMedia(raw, allowed) {
	if (raw === null || !allowed.includes(raw)) throw new ApiError(`media must be one of: ${allowed.join(", ")}.`, 400);
	return raw;
}
function queryString(params, name, maxLength) {
	const value = params.get(name);
	if (value === null) return null;
	const trimmed = value.trim();
	if (trimmed.length > maxLength) throw new ApiError(`${name} is too long.`, 400);
	return trimmed;
}
async function waitForJikanSlot() {
	const globalState = globalThis;
	const delay = Math.max(0, 400 - (Date.now() - (globalState.__t3btvJikanLastAt ?? 0)));
	if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay));
	globalState.__t3btvJikanLastAt = Date.now();
}
async function fetchJson(url, headers) {
	let response;
	try {
		response = await fetch(url, {
			...headers ? { headers } : {},
			signal: AbortSignal.timeout(12e3)
		});
	} catch {
		throw new ApiError("The catalog provider could not be reached. Please try again.", 502);
	}
	if (!response.ok) {
		if (response.status === 404) throw new ApiError("The requested title was not found.", 404);
		if (response.status === 429) throw new ApiError("The catalog provider is rate-limiting requests. Please try again shortly.", 503);
		throw new ApiError("The catalog provider returned an error. Please try again later.", 502);
	}
	try {
		return record(await response.json());
	} catch {
		throw new ApiError("The catalog provider returned an invalid response.", 502);
	}
}
async function tmdb(path, params) {
	const token = processModule.env["TMDB_READ_ACCESS_TOKEN"];
	if (!token) throw new ApiError("Catalog service is not configured: TMDB access is unavailable.", 503);
	params.set("language", "ar-SA");
	if (!params.has("region")) params.set("region", "SA");
	const url = new URL(`${TMDB_BASE}${path}`);
	const isV3ApiKey = /^[a-f\d]{32}$/i.test(token);
	if (isV3ApiKey) params.set("api_key", token);
	url.search = params.toString();
	return fetchJson(url, {
		...isV3ApiKey ? {} : { Authorization: `Bearer ${token}` },
		Accept: "application/json"
	});
}
async function jikan(path, params) {
	await waitForJikanSlot();
	const url = new URL(`${JIKAN_BASE}${path}`);
	url.search = params.toString();
	return fetchJson(url, { Accept: "application/json" });
}
function tmdbResponse(payload, forcedType) {
	const results = list(payload.results).map((item) => normalizeTmdb(item, forcedType)).filter((item) => item.id && item.title);
	return {
		results,
		total_pages: finiteNumber(payload.total_pages) ?? 1,
		total_results: finiteNumber(payload.total_results) ?? results.length
	};
}
function animeResponse(payload) {
	const results = list(payload.data).map(normalizeAnime).filter((item) => item.id && item.title);
	const pagination = record(payload.pagination);
	return {
		results,
		total_pages: finiteNumber(pagination.last_visible_page) ?? 1,
		total_results: finiteNumber(record(pagination.items).total) ?? results.length
	};
}
function tmdbAnimeResponse(payload, japaneseOnly = false) {
	const results = list(payload.results).filter((value) => {
		if (!japaneseOnly) return true;
		const item = record(value);
		return item["original_language"] === "ja" && list(item.genre_ids).map(String).includes("16");
	}).map((value) => {
		const raw = record(value);
		const item = normalizeTmdb(raw, "anime");
		const sourceMedia = raw.media_type === "movie" ? "movie" : "tv";
		return {
			...item,
			id: `tmdb-${sourceMedia}-${item.id}`
		};
	}).filter((item) => item.id && item.title);
	return {
		results,
		total_pages: finiteNumber(payload.total_pages) ?? 1,
		total_results: japaneseOnly ? results.length : finiteNumber(payload.total_results) ?? results.length
	};
}
async function tmdbAnimeDiscovery(params, page) {
	const fallback = new URLSearchParams({
		page: String(page),
		sort_by: "popularity.desc",
		with_origin_country: "JP",
		with_original_language: "ja",
		with_genres: "16"
	});
	const genre = queryString(params, "genre", 64);
	if (genre) {
		const extras = genre.split(",").map((id) => id.trim()).filter((id) => id && id !== "16");
		if (extras.length) fallback.set("with_genres", ["16", ...extras].join(","));
	}
	discoverYear(fallback, queryString(params, "year", 4), "tv");
	discoverRating(fallback, queryString(params, "rating", 5), "tv");
	return tmdbAnimeResponse(await tmdb("/discover/tv", fallback));
}
async function tmdbAnimeSearch(query, page) {
	return tmdbAnimeResponse(await tmdb("/search/multi", new URLSearchParams({
		query,
		page: String(page),
		include_adult: "false"
	})), true);
}
function discoverYear(params, year, media) {
	if (year === null || year === "") return;
	if (!/^\d{4}$/.test(year) || Number(year) < 1900 || Number(year) > 2100) throw new ApiError("year must be a four-digit year between 1900 and 2100.", 400);
	if (media === "anime") {
		params.set("start_date", `${year}-01-01`);
		params.set("end_date", `${year}-12-31`);
	} else if (media === "movie") params.set("primary_release_year", year);
	else params.set("first_air_date_year", year);
}
function discoverRating(params, rating, media) {
	if (rating === null || rating === "") return;
	const minimum = Number(rating);
	if (!Number.isFinite(minimum) || minimum < 0 || minimum > 10) throw new ApiError("rating must be a number between 0 and 10.", 400);
	params.set(media === "anime" ? "min_score" : "vote_average.gte", String(minimum));
}
function setGenre(params, genre, media) {
	if (genre === null || genre === "") return;
	if (!/^[\d,\s]{1,64}$/.test(genre)) throw new ApiError("genre must contain numeric genre IDs.", 400);
	if (media === "anime") {
		const animeGenres = genre.split(",").map((id) => tmdbToAnimeGenre[id.trim()]).filter(Boolean);
		if (animeGenres.length) params.set("genres", animeGenres.join(","));
		return;
	}
	params.set("with_genres", genre.replace(/\s/g, ""));
}
async function catalogResponse(params, media, page) {
	const tmdbParams = new URLSearchParams({ page: String(page) });
	const genre = queryString(params, "genre", 64);
	const year = queryString(params, "year", 4);
	const rating = queryString(params, "rating", 5);
	if (media === "anime") {
		const animeParams = new URLSearchParams({
			page: String(page),
			limit: "25"
		});
		setGenre(animeParams, genre, media);
		discoverYear(animeParams, year, media);
		discoverRating(animeParams, rating, media);
		animeParams.set("order_by", "popularity");
		animeParams.set("sort", "asc");
		try {
			return animeResponse(await jikan("/anime", animeParams));
		} catch {
			return tmdbAnimeDiscovery(params, page);
		}
	}
	setGenre(tmdbParams, genre, media);
	discoverYear(tmdbParams, year, media);
	discoverRating(tmdbParams, rating, media);
	tmdbParams.set("sort_by", "popularity.desc");
	return tmdbResponse(await tmdb(`/discover/${media}`, tmdbParams), media);
}
async function details(media, rawId) {
	if (media === "anime") {
		const tmdbAnime = /^tmdb-(movie|tv)-(\d{1,12})$/.exec(rawId);
		if (tmdbAnime?.[1] && tmdbAnime[2]) return {
			...await details(tmdbAnime[1], tmdbAnime[2]),
			id: rawId,
			mediaType: "anime"
		};
		if (!/^\d{1,12}$/.test(rawId) || Number(rawId) < 1) throw new ApiError("id must be a positive numeric anime ID.", 400);
		const payload = await jikan(`/anime/${rawId}/full`, new URLSearchParams());
		const anime = normalizeAnime(payload.data);
		const item = record(payload.data);
		const trailerMatch = text(record(item.trailer).url).match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{6,})/);
		return {
			...anime,
			...animeRuntimeMinutes(item.duration) !== null ? { runtime: animeRuntimeMinutes(item.duration) } : {},
			...trailerMatch?.[1] ? { trailerKey: trailerMatch[1] } : {}
		};
	}
	if (!/^\d{1,12}$/.test(rawId) || Number(rawId) < 1) throw new ApiError("id must be a positive numeric TMDB ID.", 400);
	const extra = new URLSearchParams({ append_to_response: "videos,watch/providers" });
	const item = record(await tmdb(`/${media}/${rawId}`, extra));
	const videos = list(record(item.videos).results).map(record);
	const trailer = videos.find((video) => video.site === "YouTube" && video.type === "Trailer" && video.official === true) ?? videos.find((video) => video.site === "YouTube" && video.type === "Trailer");
	const tmdbLink = text(record(record(record(item["watch/providers"]).results).SA).link);
	const tmdbDetailUrl = `https://www.themoviedb.org/${media === "tv" ? "tv" : "movie"}/${rawId}`;
	const watchUrl = tmdbLink.startsWith("https://") ? tmdbLink : tmdbDetailUrl;
	const seasons = list(item.seasons).map((seasonValue) => {
		const season = record(seasonValue);
		return {
			id: String(season.id ?? ""),
			name: text(season.name),
			seasonNumber: finiteNumber(season.season_number) ?? 0,
			episodeCount: finiteNumber(season.episode_count) ?? 0,
			poster: imageUrl(season.poster_path, "w500"),
			airDate: text(season.air_date) || null
		};
	});
	const base = normalizeTmdb(item, media);
	const runtime = media === "movie" ? finiteNumber(item.runtime) : finiteNumber(list(item.episode_run_time)[0]);
	return {
		...base,
		genres: tmdbGenres(item.genres),
		...media === "tv" ? { seasons } : {},
		...runtime !== null ? { runtime } : {},
		...text(trailer?.key) ? { trailerKey: text(trailer?.key) } : {},
		watchUrl
	};
}
async function handleCatalog(request) {
	try {
		const params = new URL(request.url).searchParams;
		const mode = queryString(params, "mode", 16) ?? "trending";
		const validModes = [
			"trending",
			"movies",
			"series",
			"top",
			"hollywood",
			"anime",
			"discover",
			"search",
			"details"
		];
		if (!validModes.includes(mode)) throw new ApiError(`mode must be one of: ${validModes.join(", ")}.`, 400);
		const page = parsePage(params.get("page"));
		if (mode === "details") {
			const rawId = queryString(params, "id", 32);
			if (!rawId) throw new ApiError("id is required for details mode.", 400);
			const media = parseMedia(params.get("media"), [
				"movie",
				"tv",
				"anime"
			]);
			return Response.json(await details(media, rawId));
		}
		if (mode === "search") {
			const q = queryString(params, "q", 200);
			if (!q) throw new ApiError("q is required for search mode.", 400);
			const mediaParam = params.get("media");
			if (mediaParam === "anime") {
				const animeParams = new URLSearchParams({
					q,
					page: String(page),
					limit: "25"
				});
				setGenre(animeParams, queryString(params, "genre", 64), "anime");
				discoverYear(animeParams, queryString(params, "year", 4), "anime");
				discoverRating(animeParams, queryString(params, "rating", 5), "anime");
				try {
					const payload = await jikan("/anime", animeParams);
					return Response.json(animeResponse(payload));
				} catch {
					const fallback = await tmdbAnimeSearch(q, page);
					const genre = queryString(params, "genre", 64);
					const year = queryString(params, "year", 4);
					const rating = queryString(params, "rating", 5);
					const selected = genre?.split(",").map((id) => genreNames[id]).filter(Boolean) ?? [];
					const results = fallback.results.filter((item) => (!year || item.year === year) && (!rating || (item.rating ?? 0) >= Number(rating)) && (!selected.length || item.genres.some((name) => selected.includes(name))));
					return Response.json({
						...fallback,
						results,
						total_results: results.length
					});
				}
			}
			const media = mediaParam === null ? null : parseMedia(mediaParam, ["movie", "tv"]);
			const payload = await tmdb(media === null ? "/search/multi" : `/search/${media}`, new URLSearchParams({
				query: q,
				page: String(page),
				include_adult: "false"
			}));
			const genre = queryString(params, "genre", 64);
			const year = queryString(params, "year", 4);
			const rating = queryString(params, "rating", 5);
			const matchesFilters = (item) => {
				if (year && item.year !== year) return false;
				if (rating && (item.rating ?? 0) < Number(rating)) return false;
				if (genre) {
					const selected = genre.split(",").map((id) => genreNames[id]).filter(Boolean);
					if (selected.includes("رسوم متحركة") && item.mediaType === "anime") return true;
					if (selected.length && !item.genres.some((name) => selected.includes(name))) return false;
				}
				return true;
			};
			if (media !== null) {
				const result = tmdbResponse(payload, media);
				return Response.json({
					...result,
					results: result.results.filter(matchesFilters)
				});
			}
			const multi = tmdbResponse(payload);
			const tmdbResults = list(payload.results).filter((value) => ["movie", "tv"].includes(text(record(value).media_type))).map((value) => normalizeTmdb(value)).filter(matchesFilters);
			const animePayload = await jikan("/anime", new URLSearchParams({
				q,
				page: String(page),
				limit: "25"
			})).catch(() => null);
			const fallbackAnime = animePayload ? null : tmdbAnimeResponse(payload, true);
			const animeResults = animePayload ? animeResponse(animePayload).results.filter(matchesFilters) : fallbackAnime?.results.filter(matchesFilters) ?? [];
			return Response.json({
				...multi,
				results: [...tmdbResults, ...animeResults],
				total_results: (finiteNumber(payload.total_results) ?? tmdbResults.length) + (animePayload ? animeResponse(animePayload).total_results : fallbackAnime?.total_results ?? 0),
				total_pages: Math.max(multi.total_pages, animePayload ? animeResponse(animePayload).total_pages : fallbackAnime?.total_pages ?? 1)
			});
		}
		if (mode === "discover") {
			const media = parseMedia(params.get("media"), [
				"movie",
				"tv",
				"anime"
			]);
			return Response.json(await catalogResponse(params, media, page));
		}
		if (mode === "hollywood") {
			const discoverParams = new URLSearchParams({
				page: String(page),
				sort_by: "popularity.desc",
				with_origin_country: "US"
			});
			setGenre(discoverParams, queryString(params, "genre", 64), "movie");
			discoverYear(discoverParams, queryString(params, "year", 4), "movie");
			discoverRating(discoverParams, queryString(params, "rating", 5), "movie");
			return Response.json(tmdbResponse(await tmdb("/discover/movie", discoverParams), "movie"));
		}
		if (mode === "anime") {
			if (params.has("genre") || params.has("year") || params.has("rating")) return Response.json(await catalogResponse(params, "anime", page));
			try {
				const payload = await jikan("/top/anime", new URLSearchParams({
					page: String(page),
					limit: "25"
				}));
				return Response.json(animeResponse(payload));
			} catch {
				return Response.json(await tmdbAnimeDiscovery(params, page));
			}
		}
		if (mode === "movies") {
			if (params.has("genre") || params.has("year") || params.has("rating")) return Response.json(await catalogResponse(params, "movie", page));
			const payload = await tmdb("/movie/now_playing", new URLSearchParams({
				page: String(page),
				region: "SA"
			}));
			return Response.json(tmdbResponse(payload, "movie"));
		}
		if (mode === "series") {
			const payload = await tmdb("/tv/on_the_air", new URLSearchParams({ page: String(page) }));
			return Response.json(tmdbResponse(payload, "tv"));
		}
		if (mode === "top") {
			const media = parseMedia(params.get("media") ?? "movie", [
				"movie",
				"tv",
				"anime"
			]);
			const genre = queryString(params, "genre", 64);
			const year = queryString(params, "year", 4);
			const rating = queryString(params, "rating", 5);
			if (media === "anime") {
				const animeParams = new URLSearchParams({
					page: String(page),
					limit: "25",
					order_by: "score",
					sort: "desc"
				});
				setGenre(animeParams, genre, media);
				discoverYear(animeParams, year, media);
				discoverRating(animeParams, rating, media);
				try {
					return Response.json(animeResponse(await jikan("/top/anime", animeParams)));
				} catch {
					return Response.json(await tmdbAnimeDiscovery(params, page));
				}
			}
			if (genre || year || rating) {
				const discoverParams = new URLSearchParams({
					page: String(page),
					sort_by: "vote_average.desc",
					"vote_count.gte": "200"
				});
				setGenre(discoverParams, genre, media);
				discoverYear(discoverParams, year, media);
				discoverRating(discoverParams, rating, media);
				return Response.json(tmdbResponse(await tmdb(`/discover/${media}`, discoverParams), media));
			}
			const payload = await tmdb(`/${media}/top_rated`, new URLSearchParams({
				page: String(page),
				region: "SA"
			}));
			return Response.json(tmdbResponse(payload, media));
		}
		const payload = await tmdb("/trending/all/week", new URLSearchParams({ page: String(page) }));
		const results = list(payload.results).filter((value) => ["movie", "tv"].includes(text(record(value).media_type))).map((value) => normalizeTmdb(value));
		return Response.json({
			results,
			total_pages: finiteNumber(payload.total_pages) ?? 1,
			total_results: finiteNumber(payload.total_results) ?? results.length
		});
	} catch (error) {
		if (error instanceof ApiError) return Response.json({ error: error.message }, { status: error.status });
		return Response.json({ error: "An unexpected catalog error occurred. Please try again later." }, { status: 500 });
	}
}
var Route$1 = createFileRoute("/api/catalog")({ server: { handlers: { GET: ({ request }) => handleCatalog(request) } } });
var TABLE_NAME = "t3btv_watchlist_items";
var MAX_ITEMS = 500;
var MAX_BODY_BYTES = 5 * 1024 * 1024;
var UUID_V4_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
var mediaTypes = [
	"movie",
	"tv",
	"anime"
];
var WatchlistError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.status = status;
		this.name = "WatchlistError";
	}
};
function isObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function requiredString(value, label, maxLength) {
	if (typeof value !== "string") throw new WatchlistError(`${label} must be a string.`, 400);
	const result = value.trim();
	if (!result || result.length > maxLength) throw new WatchlistError(`${label} must be between 1 and ${maxLength} characters.`, 400);
	return result;
}
function nullableImage(value, label) {
	if (value === null || value === void 0 || value === "") return null;
	if (typeof value !== "string" || value.length > 2048) throw new WatchlistError(`${label} must be a TMDB image URL or null.`, 400);
	try {
		const url = new URL(value);
		const tmdbImage = url.hostname === "image.tmdb.org" && /^\/t\/p\/(?:w500|w1280)\//.test(url.pathname);
		const jikanImage = url.hostname === "cdn.myanimelist.net" && url.pathname.startsWith("/images/");
		if (url.protocol !== "https:" || !tmdbImage && !jikanImage) throw new Error("not an allowed TMDB image URL");
		return url.toString();
	} catch {
		throw new WatchlistError(`${label} must be a TMDB image URL or null.`, 400);
	}
}
function validateItem(value) {
	if (!isObject(value)) throw new WatchlistError("Each watchlist item must be an object.", 400);
	const id = requiredString(value.id, "id", 128);
	if (!/^[\w:-]+$/.test(id)) throw new WatchlistError("id contains unsupported characters.", 400);
	const title = requiredString(value.title, "title", 500);
	if (value.overview !== void 0 && typeof value.overview !== "string") throw new WatchlistError("overview must be a string.", 400);
	const overview = typeof value.overview === "string" ? value.overview : "";
	if (overview.length > 5e3) throw new WatchlistError("overview is too long.", 400);
	if (typeof value.mediaType !== "string" || !mediaTypes.includes(value.mediaType)) throw new WatchlistError("mediaType must be movie, tv, or anime.", 400);
	const mediaType = value.mediaType;
	const year = value.year === null || value.year === void 0 || value.year === "" ? null : requiredString(value.year, "year", 4);
	if (year !== null && !/^\d{4}$/.test(year)) throw new WatchlistError("year must be a four-digit year or null.", 400);
	const rating = value.rating === null || value.rating === void 0 ? null : value.rating;
	if (rating !== null && (typeof rating !== "number" || !Number.isFinite(rating) || rating < 0 || rating > 10)) throw new WatchlistError("rating must be between 0 and 10, or null.", 400);
	const rawGenres = value.genres ?? [];
	if (!Array.isArray(rawGenres) || rawGenres.length > 30) throw new WatchlistError("genres must be an array with at most 30 entries.", 400);
	const genres = rawGenres.map((genre) => requiredString(genre, "genre", 80));
	const seasonCount = value.seasonCount;
	if (seasonCount !== void 0 && (typeof seasonCount !== "number" || !Number.isInteger(seasonCount) || seasonCount < 0 || seasonCount > 1e3)) throw new WatchlistError("seasonCount must be an integer between 0 and 1000.", 400);
	return {
		id,
		title,
		overview,
		poster: nullableImage(value.poster, "poster"),
		backdrop: nullableImage(value.backdrop, "backdrop"),
		mediaType,
		year,
		rating,
		genres,
		...seasonCount !== void 0 ? { seasonCount } : {}
	};
}
function parseProfileId(value) {
	if (!value || !UUID_V4_PATTERN.test(value)) throw new WatchlistError("A valid browser profileId UUID v4 is required.", 400);
	return value.toLowerCase();
}
function getPool() {
	const databaseUrl = processModule.env["DATABASE_URL"];
	if (!databaseUrl) throw new WatchlistError("Watchlist storage is unavailable because DATABASE_URL is not configured; use the browser's local fallback.", 503);
	const state = globalThis;
	if (!state.__t3btvWatchlistPool) state.__t3btvWatchlistPool = (0, import_promise.createPool)(databaseUrl);
	return state.__t3btvWatchlistPool;
}
async function ensureSchema(pool) {
	const state = globalThis;
	if (!state.__t3btvWatchlistSchema) state.__t3btvWatchlistSchema = pool.execute(`CREATE TABLE IF NOT EXISTS ${TABLE_NAME} (
        profile_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
        media_type ENUM('movie', 'tv', 'anime') NOT NULL,
        media_id VARCHAR(128) NOT NULL,
        media_json JSON NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (profile_id, media_type, media_id),
        KEY idx_t3btv_watchlist_profile_updated (profile_id, updated_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`).then(() => void 0).catch((error) => {
		state.__t3btvWatchlistSchema = void 0;
		throw error;
	});
	await state.__t3btvWatchlistSchema;
}
async function withStorage(operation) {
	const pool = getPool();
	try {
		await ensureSchema(pool);
		return await operation(pool);
	} catch (error) {
		if (error instanceof WatchlistError) throw error;
		throw new WatchlistError("Watchlist storage could not be reached. Please use local storage or try again later.", 503);
	}
}
async function readWatchlist(profileId) {
	const items = await withStorage(async (pool) => {
		const [rows] = await pool.execute(`SELECT media_json FROM ${TABLE_NAME} WHERE profile_id = ? ORDER BY updated_at DESC LIMIT ?`, [profileId, MAX_ITEMS]);
		if (!Array.isArray(rows)) return [];
		const result = [];
		for (const row of rows) {
			if (!isObject(row)) continue;
			let saved = row.media_json;
			if (typeof saved === "string") try {
				saved = JSON.parse(saved);
			} catch {
				continue;
			}
			try {
				result.push(validateItem(saved));
			} catch {}
		}
		return result;
	});
	return Response.json({
		profileId,
		items
	});
}
async function replaceWatchlist(request, profileId) {
	if (Number(request.headers.get("content-length") ?? "0") > MAX_BODY_BYTES) throw new WatchlistError("The watchlist request is too large.", 413);
	const rawBody = await request.text();
	if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) throw new WatchlistError("The watchlist request is too large.", 413);
	let body;
	try {
		body = JSON.parse(rawBody);
	} catch {
		throw new WatchlistError("Request body must be valid JSON.", 400);
	}
	if (!isObject(body)) throw new WatchlistError("Request body must be an object.", 400);
	if (parseProfileId(typeof body.profileId === "string" ? body.profileId : null) !== profileId) throw new WatchlistError("profileId in the request URL and body must match.", 400);
	if (!Array.isArray(body.items)) throw new WatchlistError("items must be an array.", 400);
	if (body.items.length > MAX_ITEMS) throw new WatchlistError(`A watchlist can contain at most ${MAX_ITEMS} items.`, 400);
	const items = body.items.map(validateItem);
	const uniqueItems = /* @__PURE__ */ new Map();
	for (const item of items) uniqueItems.set(`${item.mediaType}:${item.id}`, item);
	if (uniqueItems.size > MAX_ITEMS) throw new WatchlistError(`A watchlist can contain at most ${MAX_ITEMS} unique items.`, 400);
	await withStorage(async (pool) => {
		const connection = await pool.getConnection();
		try {
			await connection.beginTransaction();
			await connection.execute(`DELETE FROM ${TABLE_NAME} WHERE profile_id = ?`, [profileId]);
			for (const item of uniqueItems.values()) await connection.execute(`INSERT INTO ${TABLE_NAME} (profile_id, media_type, media_id, media_json)
           VALUES (?, ?, ?, CAST(? AS JSON))`, [
				profileId,
				item.mediaType,
				item.id,
				JSON.stringify(item)
			]);
			await connection.commit();
		} catch (error) {
			await connection.rollback();
			throw error;
		} finally {
			connection.release();
		}
	});
	return Response.json({
		profileId,
		items: [...uniqueItems.values()]
	});
}
async function handleWatchlist(request, method) {
	try {
		let rawProfileId = new URL(request.url).searchParams.get("profileId");
		if (!rawProfileId && method === "PUT") try {
			const body = await request.clone().json();
			if (isObject(body) && typeof body.profileId === "string") rawProfileId = body.profileId;
		} catch {}
		const profileId = parseProfileId(rawProfileId);
		return method === "GET" ? await readWatchlist(profileId) : await replaceWatchlist(request, profileId);
	} catch (error) {
		if (error instanceof WatchlistError) return Response.json({ error: error.message }, { status: error.status });
		return Response.json({ error: "An unexpected watchlist error occurred. Please try again later." }, { status: 500 });
	}
}
var Route = createFileRoute("/api/watchlist")({ server: { handlers: {
	GET: ({ request }) => handleWatchlist(request, "GET"),
	PUT: ({ request }) => handleWatchlist(request, "PUT")
} } });
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	ApiCatalogRoute: Route$1.update({
		id: "/api/catalog",
		path: "/api/catalog",
		getParentRoute: () => Route$3
	}),
	ApiWatchlistRoute: Route.update({
		id: "/api/watchlist",
		path: "/api/watchlist",
		getParentRoute: () => Route$3
	}),
	MovieIdRoute: Route$4.update({
		id: "/movie/$id",
		path: "/movie/$id",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
