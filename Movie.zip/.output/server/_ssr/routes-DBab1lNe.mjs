import { o as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { d as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as putWatchlist, r as getWatchlist, t as getCatalog } from "./catalog-client-CNNkebYi.mjs";
import { a as SlidersHorizontal, c as Heart, d as Clapperboard, g as Bookmark, i as Sparkles, l as Film, m as Check, n as Tv, o as Search, p as ChevronLeft, r as Star, s as Play, t as X, v as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DBab1lNe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sectionLabels = {
	home: "الرئيسية",
	movies: "أفلام",
	hollywood: "هوليوود",
	series: "مسلسلات",
	anime: "أنمي",
	top: "الأعلى تقييمًا",
	recent: "حديثًا",
	favorites: "قائمتي"
};
var mediaOptions = [
	{
		value: "all",
		label: "كل الأنواع"
	},
	{
		value: "movie",
		label: "أفلام"
	},
	{
		value: "tv",
		label: "مسلسلات"
	},
	{
		value: "anime",
		label: "أنمي"
	}
];
var genreOptions = [
	{
		value: "28",
		label: "أكشن"
	},
	{
		value: "12",
		label: "مغامرة"
	},
	{
		value: "16",
		label: "رسوم متحركة"
	},
	{
		value: "35",
		label: "كوميديا"
	},
	{
		value: "80",
		label: "جريمة"
	},
	{
		value: "18",
		label: "دراما"
	},
	{
		value: "14",
		label: "فانتازيا"
	},
	{
		value: "27",
		label: "رعب"
	},
	{
		value: "878",
		label: "خيال علمي"
	},
	{
		value: "53",
		label: "تشويق"
	}
];
function Index() {
	const [section, setSection] = (0, import_react.useState)("home");
	const [searchInput, setSearchInput] = (0, import_react.useState)("");
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [mediaFilter, setMediaFilter] = (0, import_react.useState)("all");
	const [genre, setGenre] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)("");
	const [rating, setRating] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [watchlist, setWatchlist] = (0, import_react.useState)([]);
	const [profileId, setProfileId] = (0, import_react.useState)("");
	const [watchlistReady, setWatchlistReady] = (0, import_react.useState)(false);
	const [syncFailed, setSyncFailed] = (0, import_react.useState)(false);
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let profile = window.localStorage.getItem("t3b-profile-id");
		if (!profile) {
			profile = window.crypto.randomUUID();
			window.localStorage.setItem("t3b-profile-id", profile);
		}
		setProfileId(profile);
		let localItems = [];
		const localValue = window.localStorage.getItem("t3b-watchlist");
		if (localValue) try {
			localItems = JSON.parse(localValue);
			setWatchlist(localItems);
		} catch {
			window.localStorage.removeItem("t3b-watchlist");
		}
		setWatchlistReady(true);
		getWatchlist(profile).then(async (items) => {
			if (items.length) {
				setWatchlist(items);
				window.localStorage.setItem("t3b-watchlist", JSON.stringify(items));
			} else if (localItems.length) await putWatchlist(profile, localItems);
			setSyncFailed(false);
		}).catch(() => setSyncFailed(true));
	}, []);
	const queryParams = (0, import_react.useMemo)(() => {
		const media = mediaFilter;
		const common = {
			page,
			genre,
			year,
			rating
		};
		if (searchTerm) return {
			mode: "search",
			q: searchTerm,
			...media === "all" ? {} : { media },
			...common
		};
		if (section === "movies") return {
			mode: "discover",
			media: media === "all" ? "movie" : media,
			...common
		};
		if (section === "hollywood") return {
			mode: "hollywood",
			media: "movie",
			...common
		};
		if (section === "series") return {
			mode: "discover",
			media: media === "all" ? "tv" : media,
			...common
		};
		if (section === "anime") return {
			mode: "anime",
			media: "anime",
			...common
		};
		if (section === "top") return {
			mode: "top",
			media: media === "all" ? "movie" : media,
			...common
		};
		if (section === "recent") return {
			mode: media === "anime" ? "anime" : media === "tv" ? "series" : "movies",
			media: media === "all" ? "movie" : media,
			...common
		};
		return {
			mode: "trending",
			media,
			page
		};
	}, [
		genre,
		mediaFilter,
		page,
		rating,
		searchTerm,
		section,
		year
	]);
	const { data: listing, isLoading: listingLoading, error: listingError } = useQuery({
		queryKey: ["catalog", queryParams],
		queryFn: () => getCatalog(queryParams),
		enabled: section !== "home" && section !== "favorites" || Boolean(searchTerm) || Boolean(genre || year || rating),
		staleTime: 600 * 1e3
	});
	const showShelves = section === "home" && !searchTerm && !genre && !year && !rating;
	const trending = useQuery({
		queryKey: ["shelf", "trending"],
		queryFn: () => getCatalog({
			mode: "trending",
			media: "all"
		}),
		staleTime: 900 * 1e3,
		enabled: showShelves
	});
	const movies = useQuery({
		queryKey: ["shelf", "movies"],
		queryFn: () => getCatalog({
			mode: "movies",
			media: "movie"
		}),
		staleTime: 900 * 1e3,
		enabled: showShelves
	});
	const hollywood = useQuery({
		queryKey: ["shelf", "hollywood"],
		queryFn: () => getCatalog({
			mode: "hollywood",
			media: "movie"
		}),
		staleTime: 900 * 1e3,
		enabled: showShelves
	});
	const series = useQuery({
		queryKey: ["shelf", "series"],
		queryFn: () => getCatalog({
			mode: "series",
			media: "tv"
		}),
		staleTime: 900 * 1e3,
		enabled: showShelves
	});
	const top = useQuery({
		queryKey: ["shelf", "top"],
		queryFn: () => getCatalog({
			mode: "top",
			media: "movie"
		}),
		staleTime: 900 * 1e3,
		enabled: showShelves
	});
	const anime = useQuery({
		queryKey: ["shelf", "anime"],
		queryFn: () => getCatalog({
			mode: "anime",
			media: "anime"
		}),
		staleTime: 1800 * 1e3,
		enabled: showShelves
	});
	const feature = trending.data?.results.find((item) => item.backdrop) ?? trending.data?.results[0];
	const filteredFavorites = (0, import_react.useMemo)(() => {
		const needle = searchTerm.toLocaleLowerCase();
		return watchlist.filter((item) => {
			const matchesText = !needle || item.title.toLocaleLowerCase().includes(needle);
			const matchesMedia = mediaFilter === "all" || item.mediaType === mediaFilter;
			return matchesText && matchesMedia;
		});
	}, [
		mediaFilter,
		searchTerm,
		watchlist
	]);
	function resetBrowse(next) {
		setSection(next);
		setSearchTerm("");
		setSearchInput("");
		setGenre("");
		setYear("");
		setRating("");
		setMediaFilter("all");
		setPage(1);
	}
	function submitSearch(event) {
		event.preventDefault();
		setSearchTerm(searchInput.trim());
		setSection("movies");
		setPage(1);
	}
	function toggleFavorite(item) {
		const next = watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType) ? watchlist.filter((saved) => !(saved.id === item.id && saved.mediaType === item.mediaType)) : [item, ...watchlist].slice(0, 250);
		setWatchlist(next);
		window.localStorage.setItem("t3b-watchlist", JSON.stringify(next));
		if (profileId) putWatchlist(profileId, next).then(() => setSyncFailed(false)).catch(() => setSyncFailed(true));
	}
	const favoriteView = section === "favorites" && !searchTerm && !genre && !year && !rating;
	const currentResults = favoriteView ? filteredFavorites : listing?.results ?? [];
	const pageCount = Math.max(1, listing?.total_pages ?? 1);
	const busy = favoriteView ? !watchlistReady : listingLoading;
	const heading = searchTerm ? `نتائج البحث: ${searchTerm}` : sectionLabels[section];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "site-shell min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "site-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "header-inner",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "brand",
							"aria-label": "T3B TV — الرئيسية",
							onClick: () => resetBrowse("home"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "brand-mark",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									size: 15,
									fill: "currentColor",
									strokeWidth: 0
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "brand-word",
								children: ["T3B ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "TV" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "desktop-nav",
							"aria-label": "التنقل الرئيسي",
							children: [
								"home",
								"movies",
								"hollywood",
								"series",
								"anime",
								"top",
								"favorites"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => resetBrowse(item),
								className: section === item ? "nav-link active" : "nav-link",
								children: sectionLabels[item]
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "header-search",
							onSubmit: submitSearch,
							role: "search",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									size: 17,
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: searchInput,
									onChange: (event) => setSearchInput(event.target.value),
									placeholder: "ابحث عن فيلم أو مسلسل أو أنمي",
									"aria-label": "ابحث عن فيلم أو مسلسل أو أنمي"
								}),
								searchInput && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "clear-search",
									"aria-label": "مسح البحث",
									onClick: () => {
										setSearchInput("");
										setSearchTerm("");
										resetBrowse("home");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "search-submit",
									type: "submit",
									children: "بحث"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "mobile-list-link",
							onClick: () => resetBrowse("favorites"),
							"aria-label": "قائمتي",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { size: 19 })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mobile-nav",
					"aria-label": "التنقل",
					children: [
						"home",
						"movies",
						"hollywood",
						"series",
						"anime",
						"top",
						"favorites"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => resetBrowse(item),
						className: section === item ? "mobile-nav-link active" : "mobile-nav-link",
						children: sectionLabels[item]
					}, item))
				})]
			}),
			showShelves && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "hero",
				style: feature?.backdrop ? { backgroundImage: `url("${feature.backdrop}")` } : void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-shade" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-content",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "eyebrow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 15 }), " سينما العالم، في مكان واحد"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hero-kicker",
								children: "اكتشف حكايتك القادمة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: feature?.title ?? "عالمٌ من القصص" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hero-description",
								children: feature?.overview || "من أحدث الأفلام إلى المسلسلات والأنمي من كل مكان — ابحث، اكتشف، واحفظ ما تريد مشاهدته لاحقًا."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-meta",
								children: [
									feature?.year && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: feature.year }),
									feature?.rating !== null && feature?.rating !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rating",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
												size: 14,
												fill: "currentColor"
											}),
											" ",
											feature.rating.toFixed(1)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "بيانات وصور عالية الدقة" })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-actions",
								children: [feature && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/movie/$id",
									params: { id: `${feature.mediaType}:${feature.id}` },
									className: "button-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										size: 17,
										fill: "currentColor"
									}), " اكتشف التفاصيل"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "button-ghost",
									onClick: () => resetBrowse("movies"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 17 }), " تصفح المكتبة"]
								})]
							})
						]
					}),
					feature && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: watchlist.some((item) => item.id === feature.id && item.mediaType === feature.mediaType) ? "hero-save saved" : "hero-save",
						onClick: () => toggleFavorite(feature),
						"aria-label": "إضافة للقائمة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { size: 17 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-bottom",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "اختيار اليوم" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hero-progress",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "01 / 04" })
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "home-main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "intro-strip",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "eyebrow muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { size: 15 }), " مكتبتك السينمائية"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "كل اكتشاف يبدأ بعنوان" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "فهرس واسع من السينما العالمية، يتجدد باستمرار ليجمع الأفلام والمسلسلات والأنمي في تجربة واحدة." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "يتصدر المشهد",
						subtitle: "الأعمال الأكثر تداولًا الآن",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 17 }),
						items: trending.data?.results ?? [],
						loading: trending.isLoading,
						error: trending.error,
						onMore: () => resetBrowse("movies"),
						onToggle: toggleFavorite,
						watchlist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "إصدارات حديثة",
						subtitle: "أفلام تعرض الآن في دور السينما",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { size: 17 }),
						items: movies.data?.results ?? [],
						loading: movies.isLoading,
						error: movies.error,
						onMore: () => resetBrowse("recent"),
						onToggle: toggleFavorite,
						watchlist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "هوليوود",
						subtitle: "أعمال أمريكية رائجة من الاستوديوهات الكبرى",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { size: 17 }),
						items: hollywood.data?.results ?? [],
						loading: hollywood.isLoading,
						error: hollywood.error,
						onMore: () => resetBrowse("hollywood"),
						onToggle: toggleFavorite,
						watchlist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "حكايات على حلقات",
						subtitle: "مسلسلات جديدة ومحبوبة من أنحاء العالم",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tv, { size: 17 }),
						items: series.data?.results ?? [],
						loading: series.isLoading,
						error: series.error,
						onMore: () => resetBrowse("series"),
						onToggle: toggleFavorite,
						watchlist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "تقييمات تستحق وقتك",
						subtitle: "اختيارات نالت إعجاب الجمهور",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { size: 17 }),
						items: top.data?.results ?? [],
						loading: top.isLoading,
						error: top.error,
						onMore: () => resetBrowse("top"),
						onToggle: toggleFavorite,
						watchlist
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shelf, {
						title: "عالم الأنمي",
						subtitle: "أعمال رائجة وكلاسيكيات محبوبة",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { size: 17 }),
						items: anime.data?.results ?? [],
						loading: anime.isLoading,
						error: anime.error,
						onMore: () => resetBrowse("anime"),
						onToggle: toggleFavorite,
						watchlist
					})
				]
			})] }),
			!showShelves && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "browse-main",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "browse-heading",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "eyebrow muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 15 }), " فهرس عالمي"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: heading }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: searchTerm ? "ابحث في عناوين الأفلام والمسلسلات والأنمي من مختلف البلدان." : section === "favorites" ? "عناوينك المحفوظة، لتعود إليها متى أردت." : "استخدم عوامل التصفية للوصول إلى العمل الذي تبحث عنه." })
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "filter-toggle",
							onClick: () => setFilterOpen((value) => !value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { size: 16 }), " التصفية"]
						})]
					}),
					filterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "filters-panel",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["النوع", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: mediaFilter,
								onChange: (event) => {
									setMediaFilter(event.target.value);
									setPage(1);
								},
								children: mediaOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option.value,
									children: option.label
								}, option.value))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["التصنيف", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: genre,
								onChange: (event) => {
									setGenre(event.target.value);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "كل التصنيفات"
								}), genreOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: option.value,
									children: option.label
								}, option.value))]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["سنة الإصدار", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: year,
								onChange: (event) => {
									setYear(event.target.value);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "كل السنوات"
								}), Array.from({ length: (/* @__PURE__ */ new Date()).getFullYear() - 1949 }, (_, index) => (/* @__PURE__ */ new Date()).getFullYear() - index).map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value,
									children: value
								}, value))]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["التقييم", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: rating,
								onChange: (event) => {
									setRating(event.target.value);
									setPage(1);
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "أي تقييم"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "8",
										children: "8 فأعلى"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "7",
										children: "7 فأعلى"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "6",
										children: "6 فأعلى"
									})
								]
							})] }),
							(genre || year || rating) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "clear-filters",
								onClick: () => {
									setGenre("");
									setYear("");
									setRating("");
									setPage(1);
								},
								children: ["مسح الفلاتر ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 14 })]
							})
						]
					}),
					syncFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sync-note",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { size: 15 }), " قائمتك محفوظة على هذا الجهاز؛ تعذرت مزامنتها مع التخزين السحابي مؤقتًا."]
					}),
					listingError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorNotice, {
						message: listingError.message,
						onRetry: () => window.location.reload()
					}) : busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGridLoading, {}) : currentResults.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterGrid, {
						items: currentResults,
						onToggle: toggleFavorite,
						watchlist
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						favorite: favoriteView,
						searching: Boolean(searchTerm)
					}),
					!favoriteView && listing && listing.total_pages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pagination",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: page <= 1,
								onClick: () => setPage((value) => Math.max(1, value - 1)),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 17 }), " السابق"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"صفحة ",
								page,
								" من ",
								pageCount
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: page >= pageCount,
								onClick: () => setPage((value) => Math.min(pageCount, value + 1)),
								children: ["التالي ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
									className: "flip-x",
									size: 17
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function Shelf({ title, subtitle, icon, items, loading, error, onMore, onToggle, watchlist }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "shelf-section",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shelf-heading",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shelf-icon",
				children: icon
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: subtitle })] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onMore,
				children: ["عرض المزيد ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 15 })]
			})]
		}), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shelf-message",
			children: "تعذر تحميل هذا القسم حاليًا."
		}) : loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shelf-track",
			children: Array.from({ length: 6 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "poster-skeleton" }, index))
		}) : items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shelf-track",
			children: items.slice(0, 14).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterCard, {
				item,
				saved: watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType),
				onToggle,
				compact: true
			}, `${item.mediaType}-${item.id}`))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shelf-message",
			children: "لا توجد نتائج لهذا القسم الآن."
		})]
	});
}
function PosterGrid({ items, onToggle, watchlist }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "poster-grid",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosterCard, {
			item,
			saved: watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType),
			onToggle
		}, `${item.mediaType}-${item.id}`))
	});
}
function PosterCard({ item, saved, onToggle, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: compact ? "poster-card compact" : "poster-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/movie/$id",
			params: { id: `${item.mediaType}:${item.id}` },
			className: "poster-link",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "poster-image-wrap",
					children: [
						item.poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.poster,
							alt: `ملصق ${item.title}`,
							loading: "lazy",
							className: "poster-image"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "poster-fallback",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { size: 30 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "poster-hover",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								size: 16,
								fill: "currentColor"
							}), " التفاصيل"] })
						}),
						item.rating !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "poster-rating",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									size: 12,
									fill: "currentColor"
								}),
								" ",
								item.rating.toFixed(1)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "poster-kind",
							children: item.mediaType === "movie" ? "فيلم" : item.mediaType === "tv" ? "مسلسل" : "أنمي"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: item.title }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "poster-subtitle",
					children: item.year || "سنة الإصدار غير محددة"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: saved ? "poster-save saved" : "poster-save",
			onClick: () => onToggle(item),
			"aria-label": saved ? "إزالة من قائمتي" : "إضافة إلى قائمتي",
			title: saved ? "إزالة من قائمتي" : "إضافة إلى قائمتي",
			children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { size: 16 })
		})]
	});
}
function PosterGridLoading() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "poster-grid",
		children: Array.from({ length: 18 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-skeleton",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
			]
		}, index))
	});
}
function userFacingError(message) {
	if (/not configured|access is unavailable/i.test(message)) return "مصدر البيانات غير مهيأ بعد. تحقق من إعداد TMDB.";
	if (/rate-limit/i.test(message)) return "وصل مصدر البيانات إلى الحد المؤقت للطلبات. أعد المحاولة بعد قليل.";
	return "تحقق من اتصال الإنترنت ثم أعد المحاولة بعد قليل.";
}
function ErrorNotice({ message, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "state-card error-state",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "state-icon",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "تعذر تحميل العناوين" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: userFacingError(message) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onRetry,
				children: "أعد المحاولة"
			})
		]
	});
}
function EmptyState({ favorite, searching }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "state-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "state-icon",
				children: favorite ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { size: 22 }) : searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 22 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { size: 22 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: favorite ? "قائمتك ما زالت فارغة" : "لم نعثر على عناوين" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: favorite ? "احفظ الأعمال التي تهمك لتظهر هنا." : "جرّب كلمات مختلفة أو غيّر عوامل التصفية." })
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "site-footer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "footer-brand",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "brand-mark",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						size: 13,
						fill: "currentColor",
						strokeWidth: 0
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "brand-word",
					children: ["T3B ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "TV" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "اكتشف العالم من خلال قصصه." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tmdb-credit",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://www.themoviedb.org",
					target: "_blank",
					rel: "noreferrer",
					"aria-label": "The Movie Database",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/tmdb-logo.svg",
						alt: "The Movie Database"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "هذا المنتج يستخدم TMDB API، لكنه غير معتمد أو موصى به من TMDB." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
				lang: "en",
				children: "This product uses the TMDB API but is not endorsed or certified by TMDB."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "الملصقات والتقييمات ومعلومات العناوين مقدمة من TMDB وJikan. يعرض الموقع بيانات الاكتشاف والمقاطع الدعائية وروابط المشاهدة الرسمية فقط." })
		]
	});
}
//#endregion
export { Index as component };
