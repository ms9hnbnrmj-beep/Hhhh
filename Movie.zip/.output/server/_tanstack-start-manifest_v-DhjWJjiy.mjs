//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DhjWJjiy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/ubuntu/t3btv/src/routes/__root.tsx",
		children: [
			"/",
			"/api/catalog",
			"/api/watchlist",
			"/movie/$id"
		],
		preloads: ["/assets/index-BpovCogA.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BpovCogA.js"
		} }]
	},
	"/": {
		filePath: "/home/ubuntu/t3btv/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BPxvaduj.js", "/assets/catalog-client-DYuxpsEC.js"]
	},
	"/movie/$id": {
		filePath: "/home/ubuntu/t3btv/src/routes/movie.$id.tsx",
		children: void 0,
		preloads: ["/assets/movie._id-r18uTKHs.js", "/assets/catalog-client-DYuxpsEC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
