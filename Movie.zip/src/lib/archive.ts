export type Movie = { identifier: string; title: string; year?: string; description?: string; downloads?: number };

export const CATEGORIES = [
  { key: "top", label: "الأكثر مشاهدة", q: "collection:feature_films" },
  { key: "arabic", label: "أفلام عربية", q: "mediatype:movies AND language:(Arabic OR ara)" },
  { key: "series", label: "مسلسلات", q: "collection:classic_tv" },
  { key: "anime", label: "أنمي", q: "subject:anime" },
  { key: "tv", label: "برامج تلفزيونية", q: "collection:television_inbox" },
  { key: "docs", label: "وثائقيات", q: "subject:documentary" },
  { key: "silent", label: "أفلام صامتة", q: "collection:silent_films" },
  { key: "classic", label: "كلاسيكيات", q: "collection:feature_films AND year:[1920 TO 1960]" },
  { key: "horror", label: "رعب", q: "collection:feature_films AND subject:horror" },
  { key: "comedy", label: "كوميديا", q: "collection:feature_films AND subject:comedy" },
  { key: "scifi", label: "خيال علمي", q: "collection:feature_films AND subject:(science fiction OR sci-fi)" },
  { key: "western", label: "ويسترن", q: "collection:feature_films AND subject:western" },
  { key: "cartoons", label: "رسوم متحركة", q: "collection:animationandcartoons" },
  { key: "noir", label: "فيلم نوار", q: "collection:film_noir" },
] as const;

export async function searchMovies(q: string, page = 1, rows = 36): Promise<{ items: Movie[]; total: number }> {
  const p = new URLSearchParams({ q: `(${q}) AND mediatype:movies`, rows: String(rows), page: String(page), output: "json" });
  ["identifier", "title", "year", "description", "downloads"].forEach((f) => p.append("fl[]", f));
  p.append("sort[]", "downloads desc");
  const r = await fetch(`https://archive.org/advancedsearch.php?${p}`);
  if (!r.ok) throw new Error("تعذر تحميل الأفلام");
  const d = await r.json();
  return { items: d.response.docs, total: d.response.numFound };
}

export async function getMovie(id: string) {
  const r = await fetch(`https://archive.org/metadata/${encodeURIComponent(id)}`);
  const d = await r.json();
  return d.metadata as { title: string; year?: string; date?: string; description?: string | string[]; language?: string; runtime?: string };
}

export const thumb = (id: string) => `https://archive.org/services/img/${id}`;
export const embed = (id: string) => `https://archive.org/embed/${id}`;
export const clean = (s?: string | string[]) => (Array.isArray(s) ? s.join(" ") : s ?? "").replace(/<[^>]+>/g, " ").trim();
