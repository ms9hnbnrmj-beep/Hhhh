export type MediaType = "movie" | "tv" | "anime";

export type CatalogItem = {
  id: string;
  title: string;
  overview: string;
  poster: string | null;
  backdrop: string | null;
  mediaType: MediaType;
  year: string | null;
  rating: number | null;
  genres: string[];
  seasonCount?: number;
};

export type CatalogPage = {
  results: CatalogItem[];
  total_pages: number;
  total_results: number;
};

export type CatalogDetails = CatalogItem & {
  releaseDate?: string | null;
  runtime?: number | null;
  trailerKey?: string | null;
  watchUrl?: string | null;
  seasons?: Array<{ name: string; episodeCount: number }>;
};

export type CatalogParams = {
  mode: "trending" | "movies" | "series" | "top" | "hollywood" | "anime" | "discover" | "search";
  media?: MediaType | "all";
  q?: string;
  genre?: string;
  year?: string;
  rating?: string;
  page?: number;
};

export async function getCatalog(params: CatalogParams): Promise<CatalogPage> {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== "") search.set(key, String(value));
  });
  const response = await fetch(`/api/catalog?${search.toString()}`);
  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error || "تعذر تحميل الكتالوج الآن.");
  }
  return (await response.json()) as CatalogPage;
}

export async function getCatalogDetails(
  id: string,
  media: MediaType,
): Promise<CatalogDetails> {
  const search = new URLSearchParams({ mode: "details", id, media });
  const response = await fetch(`/api/catalog?${search.toString()}`);
  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error || "تعذر تحميل تفاصيل العمل.");
  }
  return (await response.json()) as CatalogDetails;
}

export async function getWatchlist(profileId: string): Promise<CatalogItem[]> {
  const response = await fetch(`/api/watchlist?profileId=${encodeURIComponent(profileId)}`);
  if (!response.ok) throw new Error("خدمة حفظ القائمة غير متاحة الآن.");
  const body = (await response.json()) as { items?: CatalogItem[] };
  return body.items ?? [];
}

export async function putWatchlist(profileId: string, items: CatalogItem[]) {
  const response = await fetch("/api/watchlist", {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ profileId, items }),
  });
  if (!response.ok) throw new Error("تعذر مزامنة قائمة المشاهدة.");
}

export const posterUrl = (item: CatalogItem) => item.poster;

export function detailPath(item: CatalogItem) {
  return `/movie/${encodeURIComponent(`${item.mediaType}:${item.id}`)}`;
}

export function parseMediaId(value: string): { media: MediaType; id: string } | null {
  let decoded = value;
  try { decoded = decodeURIComponent(value); } catch { /* use the route value as-is */ }
  const match = /^(movie|tv|anime):(.+)$/.exec(decoded);
  if (!match?.[1] || !match[2]) return null;
  return { media: match[1] as MediaType, id: match[2] };
}
