export type CatalogMediaType = "movie" | "tv" | "anime";

export interface CatalogMedia {
  id: string;
  title: string;
  overview: string;
  poster: string | null;
  backdrop: string | null;
  mediaType: CatalogMediaType;
  year: string | null;
  rating: number | null;
  genres: string[];
  seasonCount?: number;
}

export interface CatalogResponse {
  results: CatalogMedia[];
  total_pages: number;
  total_results: number;
}

export interface CatalogDetails extends CatalogMedia {
  genres: string[];
  seasons?: Array<{
    id: string;
    name: string;
    seasonNumber: number;
    episodeCount: number;
    poster: string | null;
    airDate: string | null;
  }>;
  runtime?: number | null;
  trailerKey?: string | null;
  watchUrl?: string | null;
}
