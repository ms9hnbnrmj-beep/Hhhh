import { createFileRoute } from "@tanstack/react-router";
import type {
  CatalogDetails,
  CatalogMedia,
  CatalogMediaType,
  CatalogResponse,
} from "@/lib/catalog-types";

const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";
const JIKAN_BASE = "https://api.jikan.moe/v4";
const MAX_PAGE = 500;

type JsonRecord = Record<string, unknown> & {
  id?: unknown;
  name?: unknown;
  title?: unknown;
  original_title?: unknown;
  original_name?: unknown;
  title_english?: unknown;
  title_japanese?: unknown;
  media_type?: unknown;
  overview?: unknown;
  synopsis?: unknown;
  poster_path?: unknown;
  backdrop_path?: unknown;
  release_date?: unknown;
  first_air_date?: unknown;
  vote_average?: unknown;
  genres?: unknown;
  genre_ids?: unknown;
  number_of_seasons?: unknown;
  mal_id?: unknown;
  images?: unknown;
  jpg?: unknown;
  large_image_url?: unknown;
  maximum_image_url?: unknown;
  trailer?: unknown;
  url?: unknown;
  year?: unknown;
  aired?: unknown;
  from?: unknown;
  score?: unknown;
  episodes?: unknown;
  demographics?: unknown;
  themes?: unknown;
  duration?: unknown;
  total_pages?: unknown;
  total_results?: unknown;
  data?: unknown;
  pagination?: unknown;
  last_visible_page?: unknown;
  items?: unknown;
  total?: unknown;
  results?: unknown;
  seasons?: unknown;
  season_number?: unknown;
  episode_count?: unknown;
  air_date?: unknown;
  videos?: unknown;
  site?: unknown;
  type?: unknown;
  official?: unknown;
  key?: unknown;
  runtime?: unknown;
  episode_run_time?: unknown;
  SA?: unknown;
  link?: unknown;
};
type CatalogMode =
  | "trending"
  | "movies"
  | "series"
  | "top"
  | "hollywood"
  | "anime"
  | "discover"
  | "search"
  | "details";

class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

const genreNames: Record<string, string> = {
  "12": "مغامرة",
  "14": "فانتازيا",
  "16": "رسوم متحركة",
  "18": "دراما",
  "27": "رعب",
  "28": "أكشن",
  "35": "كوميديا",
  "36": "تاريخ",
  "37": "ويسترن",
  "53": "إثارة",
  "80": "جريمة",
  "99": "وثائقي",
  "878": "خيال علمي",
  "9648": "غموض",
  "10402": "موسيقى",
  "10749": "رومانسي",
  "10751": "عائلي",
  "10752": "حرب",
  "10759": "أكشن ومغامرة",
  "10762": "أطفال",
  "10763": "أخبار",
  "10764": "واقعي",
  "10765": "خيال علمي وفانتازيا",
  "10766": "دراما نهارية",
  "10767": "حواري",
  "10768": "حرب وسياسة",
  "10770": "فيلم تلفزيوني",
};
const animeGenreNames: Record<string, string> = {
  "1": "أكشن", "2": "مغامرة", "4": "كوميديا", "7": "غموض",
  "8": "دراما", "10": "فانتازيا", "14": "رعب", "22": "رومانسي",
  "24": "خيال علمي", "36": "حياة يومية", "41": "تشويق",
};
const tmdbToAnimeGenre: Record<string, string> = {
  "28": "1", "12": "2", "35": "4", "9648": "7", "18": "8",
  "14": "10", "27": "14", "10749": "22", "878": "24", "53": "41",
};

function record(value: unknown): JsonRecord {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as JsonRecord)
    : {};
}

function text(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function finiteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function animeRuntimeMinutes(value: unknown): number | null {
  const direct = finiteNumber(value);
  if (direct !== null) return direct;
  const duration = text(value);
  const hours = Number(duration.match(/(\d+)\s*hour/i)?.[1] ?? 0);
  const minutes = Number(duration.match(/(\d+)\s*min/i)?.[1] ?? 0);
  const totalMinutes = hours * 60 + minutes;
  return totalMinutes > 0 ? totalMinutes : null;
}

function list(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function imageUrl(value: unknown, size: "w500" | "w1280"): string | null {
  const path = text(value);
  return path.startsWith("/") ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}

function yearFrom(value: unknown): string | null {
  const candidate = typeof value === "number" ? String(value) : text(value);
  const match = candidate.match(/^(\d{4})/);
  return match?.[1] ?? null;
}

function tmdbGenres(value: unknown): string[] {
  return list(value)
    .map((entry) => {
      const genre = record(entry);
      const name = text(genre.name);
      return name || genreNames[String(genre.id ?? "")] || "";
    })
    .filter(Boolean);
}

function tmdbGenreIds(value: unknown): string[] {
  return list(value)
    .map((id) => genreNames[String(id)] ?? "")
    .filter(Boolean);
}

function normalizeTmdb(value: unknown, forcedType?: CatalogMediaType): CatalogMedia {
  const item = record(value);
  const mediaType =
    forcedType ??
    (item.media_type === "tv" ? "tv" : item.media_type === "movie" ? "movie" : "movie");
  const title =
    text(item.title) || text(item.name) || text(item.original_title) || text(item.original_name);
  const seasonCount = finiteNumber(item.number_of_seasons);
  return {
    id: String(item.id ?? ""),
    title,
    overview: text(item.overview),
    poster: imageUrl(item.poster_path, "w500"),
    backdrop: imageUrl(item.backdrop_path, "w1280"),
    mediaType,
    year: yearFrom(item.release_date ?? item.first_air_date),
    rating: finiteNumber(item.vote_average),
    genres:
      list(item.genres).length > 0
        ? tmdbGenres(item.genres)
        : tmdbGenreIds(item.genre_ids),
    ...((mediaType === "tv" || mediaType === "anime") && seasonCount !== null ? { seasonCount } : {}),
  };
}

function normalizeAnime(value: unknown): CatalogMedia {
  const item = record(value);
  const images = record(item.images);
  const jpg = record(images.jpg);
  const trailer = record(item.trailer);
  const trailerImages = record(trailer.images);
  const title = text(item.title) || text(item.title_english) || text(item.title_japanese);
  const genres = [...list(item.genres), ...list(item.themes), ...list(item.demographics)]
    .map((entry) => {
      const genre = record(entry);
      return animeGenreNames[String(genre.mal_id ?? "")] ?? text(genre.name);
    })
    .filter(Boolean);
  const image = text(record(jpg.large_image_url).url) || text(jpg.large_image_url);
  const backdrop = text(trailerImages.maximum_image_url);
  const aired = record(item.aired);
  const score = finiteNumber(item.score);
  const episodes = finiteNumber(item.episodes);
  return {
    id: String(item.mal_id ?? ""),
    title,
    overview: text(item.synopsis),
    poster: image || null,
    backdrop: backdrop || null,
    mediaType: "anime",
    year: yearFrom(item.year ?? record(aired.from).year),
    rating: score,
    genres: [...new Set(genres)],
    ...(episodes !== null ? { seasonCount: episodes } : {}),
  };
}

function parsePage(raw: string | null): number {
  if (raw === null || raw === "") return 1;
  const page = Number(raw);
  if (!Number.isInteger(page) || page < 1 || page > MAX_PAGE) {
    throw new ApiError(`page must be an integer between 1 and ${MAX_PAGE}.`, 400);
  }
  return page;
}

function parseMedia(raw: string | null, allowed: CatalogMediaType[]): CatalogMediaType {
  if (raw === null || !allowed.includes(raw as CatalogMediaType)) {
    throw new ApiError(`media must be one of: ${allowed.join(", ")}.`, 400);
  }
  return raw as CatalogMediaType;
}

function queryString(params: URLSearchParams, name: string, maxLength: number): string | null {
  const value = params.get(name);
  if (value === null) return null;
  const trimmed = value.trim();
  if (trimmed.length > maxLength) {
    throw new ApiError(`${name} is too long.`, 400);
  }
  return trimmed;
}

async function waitForJikanSlot(): Promise<void> {
  const globalState = globalThis as typeof globalThis & { __t3btvJikanLastAt?: number };
  const now = Date.now();
  const delay = Math.max(0, 400 - (now - (globalState.__t3btvJikanLastAt ?? 0)));
  if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay));
  globalState.__t3btvJikanLastAt = Date.now();
}

async function fetchJson(url: URL, headers?: HeadersInit): Promise<JsonRecord> {
  let response: Response;
  try {
    response = await fetch(url, {
      ...(headers ? { headers } : {}),
      signal: AbortSignal.timeout(12_000),
    });
  } catch {
    throw new ApiError("The catalog provider could not be reached. Please try again.", 502);
  }
  if (!response.ok) {
    if (response.status === 404) throw new ApiError("The requested title was not found.", 404);
    if (response.status === 429) {
      throw new ApiError("The catalog provider is rate-limiting requests. Please try again shortly.", 503);
    }
    throw new ApiError("The catalog provider returned an error. Please try again later.", 502);
  }
  try {
    return record(await response.json());
  } catch {
    throw new ApiError("The catalog provider returned an invalid response.", 502);
  }
}

async function tmdb(path: string, params: URLSearchParams): Promise<JsonRecord> {
  const token = process.env["TMDB_READ_ACCESS_TOKEN"];
  if (!token) {
    throw new ApiError("Catalog service is not configured: TMDB access is unavailable.", 503);
  }
  params.set("language", "ar-SA");
  if (!params.has("region")) params.set("region", "SA");
  const url = new URL(`${TMDB_BASE}${path}`);
  const isV3ApiKey = /^[a-f\d]{32}$/i.test(token);
  if (isV3ApiKey) params.set("api_key", token);
  url.search = params.toString();
  return fetchJson(url, {
    ...(isV3ApiKey ? {} : { Authorization: `Bearer ${token}` }),
    Accept: "application/json",
  });
}

async function jikan(path: string, params: URLSearchParams): Promise<JsonRecord> {
  await waitForJikanSlot();
  const url = new URL(`${JIKAN_BASE}${path}`);
  url.search = params.toString();
  return fetchJson(url, { Accept: "application/json" });
}

function tmdbResponse(payload: JsonRecord, forcedType?: CatalogMediaType): CatalogResponse {
  const results = list(payload.results)
    .map((item) => normalizeTmdb(item, forcedType))
    .filter((item) => item.id && item.title);
  return {
    results,
    total_pages: finiteNumber(payload.total_pages) ?? 1,
    total_results: finiteNumber(payload.total_results) ?? results.length,
  };
}

function animeResponse(payload: JsonRecord): CatalogResponse {
  const results = list(payload.data)
    .map(normalizeAnime)
    .filter((item) => item.id && item.title);
  const pagination = record(payload.pagination);
  const lastPage = finiteNumber(pagination.last_visible_page) ?? 1;
  const items = record(pagination.items);
  return {
    results,
    total_pages: lastPage,
    total_results: finiteNumber(items.total) ?? results.length,
  };
}

function tmdbAnimeResponse(payload: JsonRecord, japaneseOnly = false): CatalogResponse {
  const results = list(payload.results)
    .filter((value) => {
      if (!japaneseOnly) return true;
      const item = record(value);
      return item["original_language"] === "ja" && list(item.genre_ids).map(String).includes("16");
    })
    .map((value) => {
      const raw = record(value);
      const item = normalizeTmdb(raw, "anime");
      const sourceMedia = raw.media_type === "movie" ? "movie" : "tv";
      return { ...item, id: `tmdb-${sourceMedia}-${item.id}` };
    })
    .filter((item) => item.id && item.title);
  return {
    results,
    total_pages: finiteNumber(payload.total_pages) ?? 1,
    total_results: japaneseOnly ? results.length : finiteNumber(payload.total_results) ?? results.length,
  };
}

async function tmdbAnimeDiscovery(params: URLSearchParams, page: number): Promise<CatalogResponse> {
  const fallback = new URLSearchParams({
    page: String(page), sort_by: "popularity.desc", with_origin_country: "JP",
    with_original_language: "ja", with_genres: "16",
  });
  const genre = queryString(params, "genre", 64);
  if (genre) {
    const extras = genre.split(",").map((id) => id.trim()).filter((id) => id && id !== "16");
    if (extras.length) fallback.set("with_genres", ["16", ...extras].join(","));
  }
  discoverYear(fallback, queryString(params, "year", 4), "tv");
  discoverRating(fallback, queryString(params, "rating", 5), "tv");
  return tmdbAnimeResponse(await tmdb("/discover/tv", fallback));
}

async function tmdbAnimeSearch(query: string, page: number): Promise<CatalogResponse> {
  const params = new URLSearchParams({ query, page: String(page), include_adult: "false" });
  return tmdbAnimeResponse(await tmdb("/search/multi", params), true);
}

function discoverYear(params: URLSearchParams, year: string | null, media: CatalogMediaType): void {
  if (year === null || year === "") return;
  if (!/^\d{4}$/.test(year) || Number(year) < 1900 || Number(year) > 2100) {
    throw new ApiError("year must be a four-digit year between 1900 and 2100.", 400);
  }
  if (media === "anime") {
    params.set("start_date", `${year}-01-01`);
    params.set("end_date", `${year}-12-31`);
  } else if (media === "movie") {
    params.set("primary_release_year", year);
  } else {
    params.set("first_air_date_year", year);
  }
}

function discoverRating(params: URLSearchParams, rating: string | null, media: CatalogMediaType): void {
  if (rating === null || rating === "") return;
  const minimum = Number(rating);
  if (!Number.isFinite(minimum) || minimum < 0 || minimum > 10) {
    throw new ApiError("rating must be a number between 0 and 10.", 400);
  }
  params.set(media === "anime" ? "min_score" : "vote_average.gte", String(minimum));
}

function setGenre(params: URLSearchParams, genre: string | null, media: CatalogMediaType): void {
  if (genre === null || genre === "") return;
  if (!/^[\d,\s]{1,64}$/.test(genre)) {
    throw new ApiError("genre must contain numeric genre IDs.", 400);
  }
  if (media === "anime") {
    const animeGenres = genre.split(",").map((id) => tmdbToAnimeGenre[id.trim()]).filter(Boolean);
    if (animeGenres.length) params.set("genres", animeGenres.join(","));
    return;
  }
  params.set("with_genres", genre.replace(/\s/g, ""));
}

async function catalogResponse(
  params: URLSearchParams,
  media: CatalogMediaType,
  page: number,
): Promise<CatalogResponse> {
  const tmdbParams = new URLSearchParams({ page: String(page) });
  const genre = queryString(params, "genre", 64);
  const year = queryString(params, "year", 4);
  const rating = queryString(params, "rating", 5);
  if (media === "anime") {
    const animeParams = new URLSearchParams({ page: String(page), limit: "25" });
    setGenre(animeParams, genre, media);
    discoverYear(animeParams, year, media);
    discoverRating(animeParams, rating, media);
    animeParams.set("order_by", "popularity");
    animeParams.set("sort", "asc");
    try {
      const payload = await jikan("/anime", animeParams);
      return animeResponse(payload);
    } catch {
      return tmdbAnimeDiscovery(params, page);
    }
  }
  setGenre(tmdbParams, genre, media);
  discoverYear(tmdbParams, year, media);
  discoverRating(tmdbParams, rating, media);
  tmdbParams.set("sort_by", "popularity.desc");
  const payload = await tmdb(`/discover/${media}`, tmdbParams);
  return tmdbResponse(payload, media);
}

async function details(media: CatalogMediaType, rawId: string): Promise<CatalogDetails> {
  if (media === "anime") {
    const tmdbAnime = /^tmdb-(movie|tv)-(\d{1,12})$/.exec(rawId);
    if (tmdbAnime?.[1] && tmdbAnime[2]) {
      const detail = await details(tmdbAnime[1] as "movie" | "tv", tmdbAnime[2]);
      return { ...detail, id: rawId, mediaType: "anime" };
    }
    if (!/^\d{1,12}$/.test(rawId) || Number(rawId) < 1) {
      throw new ApiError("id must be a positive numeric anime ID.", 400);
    }
    const payload = await jikan(`/anime/${rawId}/full`, new URLSearchParams());
    const anime = normalizeAnime(payload.data);
    const item = record(payload.data);
    const trailer = record(item.trailer);
    const trailerUrl = text(trailer.url);
    const trailerMatch = trailerUrl.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{6,})/);
    return {
      ...anime,
      ...(animeRuntimeMinutes(item.duration) !== null
        ? { runtime: animeRuntimeMinutes(item.duration) }
        : {}),
      ...(trailerMatch?.[1] ? { trailerKey: trailerMatch[1] } : {}),
    };
  }
  if (!/^\d{1,12}$/.test(rawId) || Number(rawId) < 1) {
    throw new ApiError("id must be a positive numeric TMDB ID.", 400);
  }
  const extra = new URLSearchParams({ append_to_response: "videos,watch/providers" });
  const payload = await tmdb(`/${media}/${rawId}`, extra);
  const item = record(payload);
  const videoData = record(item.videos);
  const videos = list(videoData.results).map(record);
  const trailer = videos.find(
    (video) => video.site === "YouTube" && video.type === "Trailer" && video.official === true,
  ) ?? videos.find((video) => video.site === "YouTube" && video.type === "Trailer");
  const providerData = record(item["watch/providers"]);
  const results = record(providerData.results);
  const sa = record(results.SA);
  const tmdbLink = text(sa.link);
  const tmdbDetailUrl = `https://www.themoviedb.org/${media === "tv" ? "tv" : "movie"}/${rawId}`;
  const watchUrl = tmdbLink.startsWith("https://") ? tmdbLink : tmdbDetailUrl;
  const seasons = list(item.seasons).map((seasonValue) => {
    const season = record(seasonValue);
    return {
      id: String(season.id ?? ""),
      name: text(season.name),
      seasonNumber: finiteNumber(season.season_number) ?? 0,
      episodeCount: finiteNumber(season.episode_count) ?? 0,
      poster: imageUrl(season.poster_path, "w500"),
      airDate: text(season.air_date) || null,
    };
  });
  const base = normalizeTmdb(item, media);
  const runtime =
    media === "movie"
      ? finiteNumber(item.runtime)
      : finiteNumber(list(item.episode_run_time)[0]);
  return {
    ...base,
    genres: tmdbGenres(item.genres),
    ...(media === "tv" ? { seasons } : {}),
    ...(runtime !== null ? { runtime } : {}),
    ...(text(trailer?.key) ? { trailerKey: text(trailer?.key) } : {}),
    watchUrl,
  };
}

async function handleCatalog(request: Request): Promise<Response> {
  try {
    const params = new URL(request.url).searchParams;
    const mode = queryString(params, "mode", 16) ?? "trending";
    const validModes: CatalogMode[] = [
      "trending",
      "movies",
      "series",
      "top",
      "hollywood",
      "anime",
      "discover",
      "search",
      "details",
    ];
    if (!validModes.includes(mode as CatalogMode)) {
      throw new ApiError(`mode must be one of: ${validModes.join(", ")}.`, 400);
    }
    const page = parsePage(params.get("page"));
    if (mode === "details") {
      const rawId = queryString(params, "id", 32);
      if (!rawId) throw new ApiError("id is required for details mode.", 400);
      const media = parseMedia(params.get("media"), ["movie", "tv", "anime"]);
      return Response.json(await details(media, rawId));
    }
    if (mode === "search") {
      const q = queryString(params, "q", 200);
      if (!q) throw new ApiError("q is required for search mode.", 400);
      const mediaParam = params.get("media");
      if (mediaParam === "anime") {
        const animeParams = new URLSearchParams({ q, page: String(page), limit: "25" });
        setGenre(animeParams, queryString(params, "genre", 64), "anime");
        discoverYear(animeParams, queryString(params, "year", 4), "anime");
        discoverRating(animeParams, queryString(params, "rating", 5), "anime");
        try {
          const payload = await jikan("/anime", animeParams);
          return Response.json(animeResponse(payload));
        } catch {
          const fallback = await tmdbAnimeSearch(q, page);
          const genre = queryString(params, "genre", 64);
          const year = queryString(params, "year", 4);
          const rating = queryString(params, "rating", 5);
          const selected = genre?.split(",").map((id) => genreNames[id]).filter(Boolean) ?? [];
          const results = fallback.results.filter((item) =>
            (!year || item.year === year) &&
            (!rating || (item.rating ?? 0) >= Number(rating)) &&
            (!selected.length || item.genres.some((name) => selected.includes(name))),
          );
          return Response.json({ ...fallback, results, total_results: results.length });
        }
      }
      const media = mediaParam === null
        ? null
        : parseMedia(mediaParam, ["movie", "tv"]);
      const searchPath = media === null ? "/search/multi" : `/search/${media}`;
      const searchParams = new URLSearchParams({ query: q, page: String(page), include_adult: "false" });
      const payload = await tmdb(searchPath, searchParams);
      const genre = queryString(params, "genre", 64);
      const year = queryString(params, "year", 4);
      const rating = queryString(params, "rating", 5);
      const matchesFilters = (item: CatalogMedia) => {
        if (year && item.year !== year) return false;
        if (rating && (item.rating ?? 0) < Number(rating)) return false;
        if (genre) {
          const selected = genre.split(",").map((id) => genreNames[id]).filter(Boolean);
          if (selected.includes("رسوم متحركة") && item.mediaType === "anime") return true;
          if (selected.length && !item.genres.some((name) => selected.includes(name))) return false;
        }
        return true;
      };
      if (media !== null) {
        const result = tmdbResponse(payload, media);
        return Response.json({ ...result, results: result.results.filter(matchesFilters) });
      }
      const multi = tmdbResponse(payload);
      const tmdbResults = list(payload.results)
        .filter((value) => ["movie", "tv"].includes(text(record(value).media_type)))
        .map((value) => normalizeTmdb(value)).filter(matchesFilters);
      const animePayload = await jikan("/anime", new URLSearchParams({ q, page: String(page), limit: "25" })).catch(() => null);
      const fallbackAnime = animePayload ? null : tmdbAnimeResponse(payload, true);
      const animeResults = animePayload
        ? animeResponse(animePayload).results.filter(matchesFilters)
        : fallbackAnime?.results.filter(matchesFilters) ?? [];
      return Response.json({
        ...multi,
        results: [...tmdbResults, ...animeResults],
        total_results: (finiteNumber(payload.total_results) ?? tmdbResults.length) + (animePayload ? animeResponse(animePayload).total_results : fallbackAnime?.total_results ?? 0),
        total_pages: Math.max(multi.total_pages, animePayload ? animeResponse(animePayload).total_pages : fallbackAnime?.total_pages ?? 1),
      } satisfies CatalogResponse);
    }
    if (mode === "discover") {
      const media = parseMedia(params.get("media"), ["movie", "tv", "anime"]);
      return Response.json(await catalogResponse(params, media, page));
    }
    if (mode === "hollywood") {
      const discoverParams = new URLSearchParams({ page: String(page), sort_by: "popularity.desc", with_origin_country: "US" });
      setGenre(discoverParams, queryString(params, "genre", 64), "movie");
      discoverYear(discoverParams, queryString(params, "year", 4), "movie");
      discoverRating(discoverParams, queryString(params, "rating", 5), "movie");
      return Response.json(tmdbResponse(await tmdb("/discover/movie", discoverParams), "movie"));
    }
    if (mode === "anime") {
      if (params.has("genre") || params.has("year") || params.has("rating")) {
        return Response.json(await catalogResponse(params, "anime", page));
      }
      try {
        const payload = await jikan("/top/anime", new URLSearchParams({ page: String(page), limit: "25" }));
        return Response.json(animeResponse(payload));
      } catch {
        return Response.json(await tmdbAnimeDiscovery(params, page));
      }
    }
    if (mode === "movies") {
      if (params.has("genre") || params.has("year") || params.has("rating")) {
        return Response.json(await catalogResponse(params, "movie", page));
      }
      const payload = await tmdb("/movie/now_playing", new URLSearchParams({ page: String(page), region: "SA" }));
      return Response.json(tmdbResponse(payload, "movie"));
    }
    if (mode === "series") {
      const payload = await tmdb("/tv/on_the_air", new URLSearchParams({ page: String(page) }));
      return Response.json(tmdbResponse(payload, "tv"));
    }
    if (mode === "top") {
      const media = parseMedia(params.get("media") ?? "movie", ["movie", "tv", "anime"]);
      const genre = queryString(params, "genre", 64);
      const year = queryString(params, "year", 4);
      const rating = queryString(params, "rating", 5);
      if (media === "anime") {
        const animeParams = new URLSearchParams({ page: String(page), limit: "25", order_by: "score", sort: "desc" });
        setGenre(animeParams, genre, media);
        discoverYear(animeParams, year, media);
        discoverRating(animeParams, rating, media);
        try {
          return Response.json(animeResponse(await jikan("/top/anime", animeParams)));
        } catch {
          return Response.json(await tmdbAnimeDiscovery(params, page));
        }
      }
      if (genre || year || rating) {
        const discoverParams = new URLSearchParams({ page: String(page), sort_by: "vote_average.desc", "vote_count.gte": "200" });
        setGenre(discoverParams, genre, media);
        discoverYear(discoverParams, year, media);
        discoverRating(discoverParams, rating, media);
        return Response.json(tmdbResponse(await tmdb(`/discover/${media}`, discoverParams), media));
      }
      const payload = await tmdb(`/${media}/top_rated`, new URLSearchParams({ page: String(page), region: "SA" }));
      return Response.json(tmdbResponse(payload, media));
    }
    const payload = await tmdb(
      "/trending/all/week",
      new URLSearchParams({ page: String(page) }),
    );
    const results = list(payload.results)
      .filter((value) => ["movie", "tv"].includes(text(record(value).media_type)))
      .map((value) => normalizeTmdb(value));
    return Response.json({
      results,
      total_pages: finiteNumber(payload.total_pages) ?? 1,
      total_results: finiteNumber(payload.total_results) ?? results.length,
    } satisfies CatalogResponse);
  } catch (error) {
    if (error instanceof ApiError) {
      return Response.json({ error: error.message }, { status: error.status });
    }
    return Response.json(
      { error: "An unexpected catalog error occurred. Please try again later." },
      { status: 500 },
    );
  }
}

export const Route = createFileRoute("/api/catalog")({
  server: {
    handlers: {
      GET: ({ request }) => handleCatalog(request),
    },
  },
});
