import { createFileRoute } from "@tanstack/react-router";
import { createPool, type Pool } from "mysql2/promise";
import type { CatalogMedia, CatalogMediaType } from "@/lib/catalog-types";

const TABLE_NAME = "t3btv_watchlist_items";
const MAX_ITEMS = 500;
const MAX_BODY_BYTES = 5 * 1024 * 1024;
const UUID_V4_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const mediaTypes: CatalogMediaType[] = ["movie", "tv", "anime"];

type WatchlistItem = CatalogMedia;
type JsonObject = Record<string, unknown> & {
  id?: unknown;
  title?: unknown;
  overview?: unknown;
  mediaType?: unknown;
  year?: unknown;
  rating?: unknown;
  genres?: unknown;
  seasonCount?: unknown;
  poster?: unknown;
  backdrop?: unknown;
  profileId?: unknown;
  items?: unknown;
  media_json?: unknown;
};
type PoolState = typeof globalThis & {
  __t3btvWatchlistPool?: Pool;
  __t3btvWatchlistSchema?: Promise<void> | undefined;
};

class WatchlistError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "WatchlistError";
  }
}

function isObject(value: unknown): value is JsonObject {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function requiredString(value: unknown, label: string, maxLength: number): string {
  if (typeof value !== "string") throw new WatchlistError(`${label} must be a string.`, 400);
  const result = value.trim();
  if (!result || result.length > maxLength) {
    throw new WatchlistError(`${label} must be between 1 and ${maxLength} characters.`, 400);
  }
  return result;
}

function nullableImage(value: unknown, label: string): string | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || value.length > 2048) {
    throw new WatchlistError(`${label} must be a TMDB image URL or null.`, 400);
  }
  try {
    const url = new URL(value);
    const tmdbImage = url.hostname === "image.tmdb.org" && /^\/t\/p\/(?:w500|w1280)\//.test(url.pathname);
    const jikanImage = url.hostname === "cdn.myanimelist.net" && url.pathname.startsWith("/images/");
    if (url.protocol !== "https:" || (!tmdbImage && !jikanImage)) {
      throw new Error("not an allowed TMDB image URL");
    }
    return url.toString();
  } catch {
    throw new WatchlistError(`${label} must be a TMDB image URL or null.`, 400);
  }
}

function validateItem(value: unknown): WatchlistItem {
  if (!isObject(value)) throw new WatchlistError("Each watchlist item must be an object.", 400);
  const id = requiredString(value.id, "id", 128);
  if (!/^[\w:-]+$/.test(id)) throw new WatchlistError("id contains unsupported characters.", 400);
  const title = requiredString(value.title, "title", 500);
  if (value.overview !== undefined && typeof value.overview !== "string") {
    throw new WatchlistError("overview must be a string.", 400);
  }
  const overview = typeof value.overview === "string" ? value.overview : "";
  if (overview.length > 5000) throw new WatchlistError("overview is too long.", 400);
  if (typeof value.mediaType !== "string" || !mediaTypes.includes(value.mediaType as CatalogMediaType)) {
    throw new WatchlistError("mediaType must be movie, tv, or anime.", 400);
  }
  const mediaType = value.mediaType as CatalogMediaType;
  const year = value.year === null || value.year === undefined || value.year === ""
    ? null
    : requiredString(value.year, "year", 4);
  if (year !== null && !/^\d{4}$/.test(year)) {
    throw new WatchlistError("year must be a four-digit year or null.", 400);
  }
  const rating = value.rating === null || value.rating === undefined
    ? null
    : value.rating;
  if (rating !== null && (typeof rating !== "number" || !Number.isFinite(rating) || rating < 0 || rating > 10)) {
    throw new WatchlistError("rating must be between 0 and 10, or null.", 400);
  }
  const rawGenres = value.genres ?? [];
  if (!Array.isArray(rawGenres) || rawGenres.length > 30) {
    throw new WatchlistError("genres must be an array with at most 30 entries.", 400);
  }
  const genres = rawGenres.map((genre) => requiredString(genre, "genre", 80));
  const seasonCount = value.seasonCount;
  if (seasonCount !== undefined &&
      (typeof seasonCount !== "number" || !Number.isInteger(seasonCount) || seasonCount < 0 || seasonCount > 1000)) {
    throw new WatchlistError("seasonCount must be an integer between 0 and 1000.", 400);
  }
  return {
    id,
    title,
    overview,
    poster: nullableImage(value.poster, "poster"),
    backdrop: nullableImage(value.backdrop, "backdrop"),
    mediaType,
    year,
    rating,
    genres,
    ...(seasonCount !== undefined ? { seasonCount } : {}),
  };
}

function parseProfileId(value: string | null): string {
  if (!value || !UUID_V4_PATTERN.test(value)) {
    throw new WatchlistError("A valid browser profileId UUID v4 is required.", 400);
  }
  return value.toLowerCase();
}

function getPool(): Pool {
  const databaseUrl = process.env["DATABASE_URL"];
  if (!databaseUrl) {
    throw new WatchlistError(
      "Watchlist storage is unavailable because DATABASE_URL is not configured; use the browser's local fallback.",
      503,
    );
  }
  const state = globalThis as PoolState;
  if (!state.__t3btvWatchlistPool) {
    state.__t3btvWatchlistPool = createPool(databaseUrl);
  }
  return state.__t3btvWatchlistPool;
}

async function ensureSchema(pool: Pool): Promise<void> {
  const state = globalThis as PoolState;
  if (!state.__t3btvWatchlistSchema) {
    state.__t3btvWatchlistSchema = pool.execute(
      `CREATE TABLE IF NOT EXISTS ${TABLE_NAME} (
        profile_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
        media_type ENUM('movie', 'tv', 'anime') NOT NULL,
        media_id VARCHAR(128) NOT NULL,
        media_json JSON NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (profile_id, media_type, media_id),
        KEY idx_t3btv_watchlist_profile_updated (profile_id, updated_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    ).then(() => undefined).catch((error: unknown) => {
      state.__t3btvWatchlistSchema = undefined;
      throw error;
    });
  }
  await state.__t3btvWatchlistSchema;
}

async function withStorage<T>(operation: (pool: Pool) => Promise<T>): Promise<T> {
  const pool = getPool();
  try {
    await ensureSchema(pool);
    return await operation(pool);
  } catch (error) {
    if (error instanceof WatchlistError) throw error;
    throw new WatchlistError("Watchlist storage could not be reached. Please use local storage or try again later.", 503);
  }
}

async function readWatchlist(profileId: string): Promise<Response> {
  const items = await withStorage(async (pool) => {
    const [rows] = await pool.execute(
      `SELECT media_json FROM ${TABLE_NAME} WHERE profile_id = ? ORDER BY updated_at DESC LIMIT ?`,
      [profileId, MAX_ITEMS],
    );
    if (!Array.isArray(rows)) return [];
    const result: WatchlistItem[] = [];
    for (const row of rows) {
      if (!isObject(row)) continue;
      let saved: unknown = row.media_json;
      if (typeof saved === "string") {
        try {
          saved = JSON.parse(saved) as unknown;
        } catch {
          continue;
        }
      }
      try {
        result.push(validateItem(saved));
      } catch {
        // Ignore a malformed legacy row rather than exposing unvalidated data.
      }
    }
    return result;
  });
  return Response.json({ profileId, items });
}

async function replaceWatchlist(request: Request, profileId: string): Promise<Response> {
  const declaredSize = Number(request.headers.get("content-length") ?? "0");
  if (declaredSize > MAX_BODY_BYTES) {
    throw new WatchlistError("The watchlist request is too large.", 413);
  }
  const rawBody = await request.text();
  if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
    throw new WatchlistError("The watchlist request is too large.", 413);
  }
  let body: unknown;
  try {
    body = JSON.parse(rawBody) as unknown;
  } catch {
    throw new WatchlistError("Request body must be valid JSON.", 400);
  }
  if (!isObject(body)) throw new WatchlistError("Request body must be an object.", 400);
  const submittedProfileId = parseProfileId(typeof body.profileId === "string" ? body.profileId : null);
  if (submittedProfileId !== profileId) {
    throw new WatchlistError("profileId in the request URL and body must match.", 400);
  }
  if (!Array.isArray(body.items)) throw new WatchlistError("items must be an array.", 400);
  if (body.items.length > MAX_ITEMS) {
    throw new WatchlistError(`A watchlist can contain at most ${MAX_ITEMS} items.`, 400);
  }
  const items = body.items.map(validateItem);
  const uniqueItems = new Map<string, WatchlistItem>();
  for (const item of items) uniqueItems.set(`${item.mediaType}:${item.id}`, item);
  if (uniqueItems.size > MAX_ITEMS) {
    throw new WatchlistError(`A watchlist can contain at most ${MAX_ITEMS} unique items.`, 400);
  }

  await withStorage(async (pool) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      await connection.execute(`DELETE FROM ${TABLE_NAME} WHERE profile_id = ?`, [profileId]);
      for (const item of uniqueItems.values()) {
        await connection.execute(
          `INSERT INTO ${TABLE_NAME} (profile_id, media_type, media_id, media_json)
           VALUES (?, ?, ?, CAST(? AS JSON))`,
          [profileId, item.mediaType, item.id, JSON.stringify(item)],
        );
      }
      await connection.commit();
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  });
  return Response.json({ profileId, items: [...uniqueItems.values()] });
}

async function handleWatchlist(request: Request, method: "GET" | "PUT"): Promise<Response> {
  try {
    const url = new URL(request.url);
    let rawProfileId = url.searchParams.get("profileId");
    if (!rawProfileId && method === "PUT") {
      try {
        const body: unknown = await request.clone().json();
        if (isObject(body) && typeof body.profileId === "string") {
          rawProfileId = body.profileId;
        }
      } catch {
        // replaceWatchlist returns the useful invalid-JSON message below.
      }
    }
    const profileId = parseProfileId(rawProfileId);
    return method === "GET"
      ? await readWatchlist(profileId)
      : await replaceWatchlist(request, profileId);
  } catch (error) {
    if (error instanceof WatchlistError) {
      return Response.json({ error: error.message }, { status: error.status });
    }
    return Response.json(
      { error: "An unexpected watchlist error occurred. Please try again later." },
      { status: 500 },
    );
  }
}

export const Route = createFileRoute("/api/watchlist")({
  server: {
    handlers: {
      GET: ({ request }) => handleWatchlist(request, "GET"),
      PUT: ({ request }) => handleWatchlist(request, "PUT"),
    },
  },
});
