import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowLeft, Bookmark, Check, ChevronLeft, Clapperboard, Film, Heart,
  Play, Search, SlidersHorizontal, Sparkles, Star, Tv, X,
} from "lucide-react";
import {
  getCatalog, getWatchlist, putWatchlist,
  type CatalogItem, type CatalogParams, type MediaType,
} from "@/lib/catalog-client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "T3B TV — اكتشف حكايتك القادمة" },
      { name: "description", content: "اكتشف أفلامًا ومسلسلات وأنمي من مختلف أنحاء العالم، وابحث حسب النوع والسنة والتقييم." },
      { property: "og:title", content: "T3B TV — اكتشف حكايتك القادمة" },
      { property: "og:description", content: "كتالوج عالمي للأفلام والمسلسلات والأنمي مع صور أصلية وتفاصيل محدثة." },
    ],
  }),
  component: Index,
});

type Section = "home" | "movies" | "hollywood" | "series" | "anime" | "top" | "recent" | "favorites";
const sectionLabels: Record<Section, string> = {
  home: "الرئيسية", movies: "أفلام", hollywood: "هوليوود", series: "مسلسلات", anime: "أنمي",
  top: "الأعلى تقييمًا", recent: "حديثًا", favorites: "قائمتي",
};
const mediaOptions: Array<{ value: "all" | MediaType; label: string }> = [
  { value: "all", label: "كل الأنواع" }, { value: "movie", label: "أفلام" },
  { value: "tv", label: "مسلسلات" }, { value: "anime", label: "أنمي" },
];
const genreOptions = [
  { value: "28", label: "أكشن" }, { value: "12", label: "مغامرة" },
  { value: "16", label: "رسوم متحركة" }, { value: "35", label: "كوميديا" },
  { value: "80", label: "جريمة" }, { value: "18", label: "دراما" },
  { value: "14", label: "فانتازيا" }, { value: "27", label: "رعب" },
  { value: "878", label: "خيال علمي" }, { value: "53", label: "تشويق" },
];

function Index() {
  const [section, setSection] = useState<Section>("home");
  const [searchInput, setSearchInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [mediaFilter, setMediaFilter] = useState<"all" | MediaType>("all");
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState("");
  const [rating, setRating] = useState("");
  const [page, setPage] = useState(1);
  const [watchlist, setWatchlist] = useState<CatalogItem[]>([]);
  const [profileId, setProfileId] = useState("");
  const [watchlistReady, setWatchlistReady] = useState(false);
  const [syncFailed, setSyncFailed] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);

  useEffect(() => {
    let profile = window.localStorage.getItem("t3b-profile-id");
    if (!profile) {
      profile = window.crypto.randomUUID();
      window.localStorage.setItem("t3b-profile-id", profile);
    }
    setProfileId(profile);
    let localItems: CatalogItem[] = [];
    const localValue = window.localStorage.getItem("t3b-watchlist");
    if (localValue) {
      try {
        localItems = JSON.parse(localValue) as CatalogItem[];
        setWatchlist(localItems);
      } catch {
        window.localStorage.removeItem("t3b-watchlist");
      }
    }
    setWatchlistReady(true);
    getWatchlist(profile)
      .then(async (items) => {
        if (items.length) {
          setWatchlist(items);
          window.localStorage.setItem("t3b-watchlist", JSON.stringify(items));
        } else if (localItems.length) {
          await putWatchlist(profile!, localItems);
        }
        setSyncFailed(false);
      })
      .catch(() => setSyncFailed(true));
  }, []);

  const queryParams = useMemo<CatalogParams>(() => {
    const media = mediaFilter;
    const common = { page, genre, year, rating };
    if (searchTerm) return { mode: "search", q: searchTerm, ...(media === "all" ? {} : { media }), ...common };
    if (section === "movies") return { mode: "discover", media: media === "all" ? "movie" : media, ...common };
    if (section === "hollywood") return { mode: "hollywood", media: "movie", ...common };
    if (section === "series") return { mode: "discover", media: media === "all" ? "tv" : media, ...common };
    if (section === "anime") return { mode: "anime", media: "anime", ...common };
    if (section === "top") return { mode: "top", media: media === "all" ? "movie" : media, ...common };
    if (section === "recent") return { mode: media === "anime" ? "anime" : media === "tv" ? "series" : "movies", media: media === "all" ? "movie" : media, ...common };
    return { mode: "trending", media, page };
  }, [genre, mediaFilter, page, rating, searchTerm, section, year]);

  const isListing = (section !== "home" && section !== "favorites") || Boolean(searchTerm) || Boolean(genre || year || rating);
  const { data: listing, isLoading: listingLoading, error: listingError } = useQuery({
    queryKey: ["catalog", queryParams], queryFn: () => getCatalog(queryParams),
    enabled: isListing, staleTime: 10 * 60 * 1000,
  });
  const showShelves = section === "home" && !searchTerm && !genre && !year && !rating;
  const trending = useQuery({ queryKey: ["shelf", "trending"], queryFn: () => getCatalog({ mode: "trending", media: "all" }), staleTime: 15 * 60 * 1000, enabled: showShelves });
  const movies = useQuery({ queryKey: ["shelf", "movies"], queryFn: () => getCatalog({ mode: "movies", media: "movie" }), staleTime: 15 * 60 * 1000, enabled: showShelves });
  const hollywood = useQuery({ queryKey: ["shelf", "hollywood"], queryFn: () => getCatalog({ mode: "hollywood", media: "movie" }), staleTime: 15 * 60 * 1000, enabled: showShelves });
  const series = useQuery({ queryKey: ["shelf", "series"], queryFn: () => getCatalog({ mode: "series", media: "tv" }), staleTime: 15 * 60 * 1000, enabled: showShelves });
  const top = useQuery({ queryKey: ["shelf", "top"], queryFn: () => getCatalog({ mode: "top", media: "movie" }), staleTime: 15 * 60 * 1000, enabled: showShelves });
  const anime = useQuery({ queryKey: ["shelf", "anime"], queryFn: () => getCatalog({ mode: "anime", media: "anime" }), staleTime: 30 * 60 * 1000, enabled: showShelves });
  const feature = trending.data?.results.find((item) => item.backdrop) ?? trending.data?.results[0];

  const filteredFavorites = useMemo(() => {
    const needle = searchTerm.toLocaleLowerCase();
    return watchlist.filter((item) => {
      const matchesText = !needle || item.title.toLocaleLowerCase().includes(needle);
      const matchesMedia = mediaFilter === "all" || item.mediaType === mediaFilter;
      return matchesText && matchesMedia;
    });
  }, [mediaFilter, searchTerm, watchlist]);

  function resetBrowse(next: Section) {
    setSection(next); setSearchTerm(""); setSearchInput(""); setGenre(""); setYear(""); setRating(""); setMediaFilter("all"); setPage(1);
  }
  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSearchTerm(searchInput.trim()); setSection("movies"); setPage(1);
  }
  function toggleFavorite(item: CatalogItem) {
    const exists = watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType);
    const next = exists
      ? watchlist.filter((saved) => !(saved.id === item.id && saved.mediaType === item.mediaType))
      : [item, ...watchlist].slice(0, 250);
    setWatchlist(next);
    window.localStorage.setItem("t3b-watchlist", JSON.stringify(next));
    if (profileId) putWatchlist(profileId, next).then(() => setSyncFailed(false)).catch(() => setSyncFailed(true));
  }

  const favoriteView = section === "favorites" && !searchTerm && !genre && !year && !rating;
  const currentResults = favoriteView ? filteredFavorites : listing?.results ?? [];
  const pageCount = Math.max(1, listing?.total_pages ?? 1);
  const busy = favoriteView ? !watchlistReady : listingLoading;
  const heading = searchTerm ? `نتائج البحث: ${searchTerm}` : sectionLabels[section];

  return (
    <div dir="rtl" className="site-shell min-h-screen bg-background text-foreground">
      <header className="site-header">
        <div className="header-inner">
          <Link to="/" className="brand" aria-label="T3B TV — الرئيسية" onClick={() => resetBrowse("home")}>
            <span className="brand-mark"><Play size={15} fill="currentColor" strokeWidth={0} /></span><span className="brand-word">T3B <b>TV</b></span>
          </Link>
          <nav className="desktop-nav" aria-label="التنقل الرئيسي">
            {(["home", "movies", "hollywood", "series", "anime", "top", "favorites"] as Section[]).map((item) => <button key={item} onClick={() => resetBrowse(item)} className={section === item ? "nav-link active" : "nav-link"}>{sectionLabels[item]}</button>)}
          </nav>
          <form className="header-search" onSubmit={submitSearch} role="search">
            <Search size={17} aria-hidden="true" /><input value={searchInput} onChange={(event) => setSearchInput(event.target.value)} placeholder="ابحث عن فيلم أو مسلسل أو أنمي" aria-label="ابحث عن فيلم أو مسلسل أو أنمي" />
            {searchInput && <button type="button" className="clear-search" aria-label="مسح البحث" onClick={() => { setSearchInput(""); setSearchTerm(""); resetBrowse("home"); }}><X size={15} /></button>}
            <button className="search-submit" type="submit">بحث</button>
          </form>
          <button className="mobile-list-link" onClick={() => resetBrowse("favorites")} aria-label="قائمتي"><Bookmark size={19} /></button>
        </div>
        <nav className="mobile-nav" aria-label="التنقل">
          {(["home", "movies", "hollywood", "series", "anime", "top", "favorites"] as Section[]).map((item) => <button key={item} onClick={() => resetBrowse(item)} className={section === item ? "mobile-nav-link active" : "mobile-nav-link"}>{sectionLabels[item]}</button>)}
        </nav>
      </header>

      {showShelves && <>
        <section className="hero" style={feature?.backdrop ? { backgroundImage: `url("${feature.backdrop}")` } : undefined}>
          <div className="hero-shade" />
          <div className="hero-content">
            <div className="eyebrow"><Sparkles size={15} /> سينما العالم، في مكان واحد</div>
            <p className="hero-kicker">اكتشف حكايتك القادمة</p>
            <h1>{feature?.title ?? "عالمٌ من القصص"}</h1>
            <p className="hero-description">{feature?.overview || "من أحدث الأفلام إلى المسلسلات والأنمي من كل مكان — ابحث، اكتشف، واحفظ ما تريد مشاهدته لاحقًا."}</p>
            <div className="hero-meta">{feature?.year && <span>{feature.year}</span>}{feature?.rating !== null && feature?.rating !== undefined && <span className="rating"><Star size={14} fill="currentColor" /> {feature.rating.toFixed(1)}</span>}<span>بيانات وصور عالية الدقة</span></div>
            <div className="hero-actions">{feature && <Link to="/movie/$id" params={{ id: `${feature.mediaType}:${feature.id}` }} className="button-primary"><Play size={17} fill="currentColor" /> اكتشف التفاصيل</Link>}<button className="button-ghost" onClick={() => resetBrowse("movies")}><Clapperboard size={17} /> تصفح المكتبة</button></div>
          </div>
          {feature && <button className={watchlist.some((item) => item.id === feature.id && item.mediaType === feature.mediaType) ? "hero-save saved" : "hero-save"} onClick={() => toggleFavorite(feature)} aria-label="إضافة للقائمة"><Bookmark size={17} /></button>}
          <div className="hero-bottom"><span>اختيار اليوم</span><span className="hero-progress"><i /></span><span>01 / 04</span></div>
        </section>
        <main className="home-main">
          <div className="intro-strip"><div><span className="eyebrow muted"><Film size={15} /> مكتبتك السينمائية</span><h2>كل اكتشاف يبدأ بعنوان</h2></div><p>فهرس واسع من السينما العالمية، يتجدد باستمرار ليجمع الأفلام والمسلسلات والأنمي في تجربة واحدة.</p></div>
          <Shelf title="يتصدر المشهد" subtitle="الأعمال الأكثر تداولًا الآن" icon={<Sparkles size={17} />} items={trending.data?.results ?? []} loading={trending.isLoading} error={trending.error} onMore={() => resetBrowse("movies")} onToggle={toggleFavorite} watchlist={watchlist} />
          <Shelf title="إصدارات حديثة" subtitle="أفلام تعرض الآن في دور السينما" icon={<Film size={17} />} items={movies.data?.results ?? []} loading={movies.isLoading} error={movies.error} onMore={() => resetBrowse("recent")} onToggle={toggleFavorite} watchlist={watchlist} />
          <Shelf title="هوليوود" subtitle="أعمال أمريكية رائجة من الاستوديوهات الكبرى" icon={<Film size={17} />} items={hollywood.data?.results ?? []} loading={hollywood.isLoading} error={hollywood.error} onMore={() => resetBrowse("hollywood")} onToggle={toggleFavorite} watchlist={watchlist} />
          <Shelf title="حكايات على حلقات" subtitle="مسلسلات جديدة ومحبوبة من أنحاء العالم" icon={<Tv size={17} />} items={series.data?.results ?? []} loading={series.isLoading} error={series.error} onMore={() => resetBrowse("series")} onToggle={toggleFavorite} watchlist={watchlist} />
          <Shelf title="تقييمات تستحق وقتك" subtitle="اختيارات نالت إعجاب الجمهور" icon={<Star size={17} />} items={top.data?.results ?? []} loading={top.isLoading} error={top.error} onMore={() => resetBrowse("top")} onToggle={toggleFavorite} watchlist={watchlist} />
          <Shelf title="عالم الأنمي" subtitle="أعمال رائجة وكلاسيكيات محبوبة" icon={<Sparkles size={17} />} items={anime.data?.results ?? []} loading={anime.isLoading} error={anime.error} onMore={() => resetBrowse("anime")} onToggle={toggleFavorite} watchlist={watchlist} />
        </main>
      </>}

      {!showShelves && <main className="browse-main">
        <div className="browse-heading"><div><span className="eyebrow muted"><Clapperboard size={15} /> فهرس عالمي</span><h1>{heading}</h1><p>{searchTerm ? "ابحث في عناوين الأفلام والمسلسلات والأنمي من مختلف البلدان." : section === "favorites" ? "عناوينك المحفوظة، لتعود إليها متى أردت." : "استخدم عوامل التصفية للوصول إلى العمل الذي تبحث عنه."}</p></div><button className="filter-toggle" onClick={() => setFilterOpen((value) => !value)}><SlidersHorizontal size={16} /> التصفية</button></div>
        {filterOpen && <div className="filters-panel">
          <label>النوع<select value={mediaFilter} onChange={(event) => { setMediaFilter(event.target.value as "all" | MediaType); setPage(1); }}>
            {mediaOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select></label>
          <label>التصنيف<select value={genre} onChange={(event) => { setGenre(event.target.value); setPage(1); }}><option value="">كل التصنيفات</option>{genreOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
          <label>سنة الإصدار<select value={year} onChange={(event) => { setYear(event.target.value); setPage(1); }}><option value="">كل السنوات</option>{Array.from({ length: new Date().getFullYear() - 1949 }, (_, index) => new Date().getFullYear() - index).map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
          <label>التقييم<select value={rating} onChange={(event) => { setRating(event.target.value); setPage(1); }}><option value="">أي تقييم</option><option value="8">8 فأعلى</option><option value="7">7 فأعلى</option><option value="6">6 فأعلى</option></select></label>
          {(genre || year || rating) && <button className="clear-filters" onClick={() => { setGenre(""); setYear(""); setRating(""); setPage(1); }}>مسح الفلاتر <X size={14} /></button>}
        </div>}
        {syncFailed && <div className="sync-note"><Bookmark size={15} /> قائمتك محفوظة على هذا الجهاز؛ تعذرت مزامنتها مع التخزين السحابي مؤقتًا.</div>}
        {listingError ? <ErrorNotice message={(listingError as Error).message} onRetry={() => window.location.reload()} /> : busy ? <PosterGridLoading /> : currentResults.length ? <PosterGrid items={currentResults} onToggle={toggleFavorite} watchlist={watchlist} /> : <EmptyState favorite={favoriteView} searching={Boolean(searchTerm)} />}
        {!favoriteView && listing && listing.total_pages > 1 && <div className="pagination"><button disabled={page <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))}><ChevronLeft size={17} /> السابق</button><span>صفحة {page} من {pageCount}</span><button disabled={page >= pageCount} onClick={() => setPage((value) => Math.min(pageCount, value + 1))}>التالي <ChevronLeft className="flip-x" size={17} /></button></div>}
      </main>}
      <Footer />
    </div>
  );
}

function Shelf({ title, subtitle, icon, items, loading, error, onMore, onToggle, watchlist }: {
  title: string; subtitle: string; icon: ReactNode; items: CatalogItem[]; loading: boolean; error: unknown;
  onMore: () => void; onToggle: (item: CatalogItem) => void; watchlist: CatalogItem[];
}) {
  return <section className="shelf-section"><div className="shelf-heading"><div><span className="shelf-icon">{icon}</span><div><h2>{title}</h2><p>{subtitle}</p></div></div><button onClick={onMore}>عرض المزيد <ArrowLeft size={15} /></button></div>
    {error ? <div className="shelf-message">تعذر تحميل هذا القسم حاليًا.</div> : loading ? <div className="shelf-track">{Array.from({ length: 6 }, (_, index) => <div className="poster-skeleton" key={index} />)}</div> : items.length ? <div className="shelf-track">{items.slice(0, 14).map((item) => <PosterCard key={`${item.mediaType}-${item.id}`} item={item} saved={watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType)} onToggle={onToggle} compact />)}</div> : <div className="shelf-message">لا توجد نتائج لهذا القسم الآن.</div>}
  </section>;
}

function PosterGrid({ items, onToggle, watchlist }: { items: CatalogItem[]; onToggle: (item: CatalogItem) => void; watchlist: CatalogItem[] }) {
  return <div className="poster-grid">{items.map((item) => <PosterCard key={`${item.mediaType}-${item.id}`} item={item} saved={watchlist.some((saved) => saved.id === item.id && saved.mediaType === item.mediaType)} onToggle={onToggle} />)}</div>;
}

function PosterCard({ item, saved, onToggle, compact = false }: { item: CatalogItem; saved: boolean; onToggle: (item: CatalogItem) => void; compact?: boolean }) {
  return <article className={compact ? "poster-card compact" : "poster-card"}><Link to="/movie/$id" params={{ id: `${item.mediaType}:${item.id}` }} className="poster-link">
    <div className="poster-image-wrap">{item.poster ? <img src={item.poster} alt={`ملصق ${item.title}`} loading="lazy" className="poster-image" /> : <div className="poster-fallback"><Clapperboard size={30} /><span>{item.title}</span></div>}<div className="poster-hover"><span><Play size={16} fill="currentColor" /> التفاصيل</span></div>{item.rating !== null && <span className="poster-rating"><Star size={12} fill="currentColor" /> {item.rating.toFixed(1)}</span>}<span className="poster-kind">{item.mediaType === "movie" ? "فيلم" : item.mediaType === "tv" ? "مسلسل" : "أنمي"}</span></div>
    <h3>{item.title}</h3><p className="poster-subtitle">{item.year || "سنة الإصدار غير محددة"}</p>
  </Link><button className={saved ? "poster-save saved" : "poster-save"} onClick={() => onToggle(item)} aria-label={saved ? "إزالة من قائمتي" : "إضافة إلى قائمتي"} title={saved ? "إزالة من قائمتي" : "إضافة إلى قائمتي"}>{saved ? <Check size={16} /> : <Heart size={16} />}</button></article>;
}

function PosterGridLoading() { return <div className="poster-grid">{Array.from({ length: 18 }, (_, index) => <div key={index} className="grid-skeleton"><div /><i /><i /></div>)}</div>; }
function userFacingError(message: string) {
  if (/not configured|access is unavailable/i.test(message)) return "مصدر البيانات غير مهيأ بعد. تحقق من إعداد TMDB.";
  if (/rate-limit/i.test(message)) return "وصل مصدر البيانات إلى الحد المؤقت للطلبات. أعد المحاولة بعد قليل.";
  return "تحقق من اتصال الإنترنت ثم أعد المحاولة بعد قليل.";
}
function ErrorNotice({ message, onRetry }: { message: string; onRetry: () => void }) { return <div className="state-card error-state"><div className="state-icon"><X size={22} /></div><h2>تعذر تحميل العناوين</h2><p>{userFacingError(message)}</p><button onClick={onRetry}>أعد المحاولة</button></div>; }
function EmptyState({ favorite, searching }: { favorite: boolean; searching: boolean }) { return <div className="state-card"><div className="state-icon">{favorite ? <Bookmark size={22} /> : searching ? <Search size={22} /> : <Film size={22} />}</div><h2>{favorite ? "قائمتك ما زالت فارغة" : "لم نعثر على عناوين"}</h2><p>{favorite ? "احفظ الأعمال التي تهمك لتظهر هنا." : "جرّب كلمات مختلفة أو غيّر عوامل التصفية."}</p></div>; }
function Footer() {
  return <footer className="site-footer"><div className="footer-brand"><span className="brand-mark"><Play size={13} fill="currentColor" strokeWidth={0} /></span><span className="brand-word">T3B <b>TV</b></span></div><p>اكتشف العالم من خلال قصصه.</p><div className="tmdb-credit"><a href="https://www.themoviedb.org" target="_blank" rel="noreferrer" aria-label="The Movie Database"><img src="/tmdb-logo.svg" alt="The Movie Database" /></a><span>هذا المنتج يستخدم TMDB API، لكنه غير معتمد أو موصى به من TMDB.</span></div><small lang="en">This product uses the TMDB API but is not endorsed or certified by TMDB.</small><small>الملصقات والتقييمات ومعلومات العناوين مقدمة من TMDB وJikan. يعرض الموقع بيانات الاكتشاف والمقاطع الدعائية وروابط المشاهدة الرسمية فقط.</small></footer>;
}
