import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ArrowRight, Bookmark, CalendarDays, ChevronRight, Clapperboard, ExternalLink, Film, Play, Star, Tv } from "lucide-react";
import { getCatalogDetails, getWatchlist, putWatchlist, parseMediaId, type CatalogItem } from "@/lib/catalog-client";

export const Route = createFileRoute("/movie/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `تفاصيل العنوان — T3B TV` },
      { name: "description", content: `اكتشف ملخص ومعلومات العنوان ${params.id} على T3B TV.` },
    ],
  }),
  component: MoviePage,
});

function MoviePage() {
  const { id: routeId } = Route.useParams();
  const parsed = parseMediaId(routeId);
  const { data, isLoading, error } = useQuery({
    queryKey: ["details", routeId],
    queryFn: () => getCatalogDetails(parsed!.id, parsed!.media),
    enabled: Boolean(parsed),
    staleTime: 30 * 60 * 1000,
  });
  const [saved, setSaved] = useState(false);
  const [profileId, setProfileId] = useState("");
  useEffect(() => {
    if (!data) return;
    const profile = window.localStorage.getItem("t3b-profile-id") || window.crypto.randomUUID();
    window.localStorage.setItem("t3b-profile-id", profile);
    setProfileId(profile);
    const id = `${data.mediaType}:${data.id}`;
    const local = window.localStorage.getItem("t3b-watchlist");
    try {
      setSaved((JSON.parse(local || "[]") as CatalogItem[]).some((item) => `${item.mediaType}:${item.id}` === id));
    } catch {
      setSaved(false);
    }
    getWatchlist(profile).then((items) => setSaved(items.some((item) => `${item.mediaType}:${item.id}` === id))).catch(() => undefined);
  }, [data]);

  function toggleSaved() {
    if (!data) return;
    const item: CatalogItem = { id: data.id, title: data.title, overview: data.overview, poster: data.poster, backdrop: data.backdrop, mediaType: data.mediaType, year: data.year, rating: data.rating, genres: data.genres, ...(data.seasonCount !== undefined ? { seasonCount: data.seasonCount } : {}) };
    let list: CatalogItem[] = [];
    try { list = JSON.parse(window.localStorage.getItem("t3b-watchlist") || "[]") as CatalogItem[]; } catch { list = []; }
    const hasItem = list.some((entry) => entry.id === item.id && entry.mediaType === item.mediaType);
    const next = hasItem ? list.filter((entry) => !(entry.id === item.id && entry.mediaType === item.mediaType)) : [item, ...list].slice(0, 250);
    setSaved(!hasItem);
    window.localStorage.setItem("t3b-watchlist", JSON.stringify(next));
    if (profileId) putWatchlist(profileId, next).catch(() => undefined);
  }

  const mediaLabel = data?.mediaType === "tv" ? "مسلسل" : data?.mediaType === "anime" ? "أنمي" : "فيلم";

  if (!parsed) return <div dir="rtl" className="detail-page"><div className="detail-empty"><h1>رابط العنوان غير صالح</h1><Link to="/">العودة إلى الصفحة الرئيسية</Link></div></div>;
  if (isLoading) return <div dir="rtl" className="detail-page"><div className="detail-loading"><div className="detail-spinner" /><p>نجهّز تفاصيل العمل...</p></div></div>;
  if (error || !data) return <div dir="rtl" className="detail-page"><div className="detail-empty"><Clapperboard size={30} /><h1>تعذر تحميل التفاصيل</h1><p>تحقق من الاتصال بمصدر البيانات ثم حاول مجددًا بعد قليل.</p><Link to="/">العودة إلى المكتبة</Link></div></div>;

  return <div dir="rtl" className="detail-page">
    <div className="detail-backdrop" style={data.backdrop ? { backgroundImage: `url("${data.backdrop}")` } : undefined} />
    <div className="detail-overlay" />
    <header className="detail-header"><Link to="/" className="brand"><span className="brand-mark"><Play size={14} fill="currentColor" strokeWidth={0} /></span><span className="brand-word">T3B <b>TV</b></span></Link><Link to="/" className="back-link"><ChevronRight size={18} /> العودة إلى الاستكشاف</Link></header>
    <main className="detail-content">
      <div className="detail-poster">{data.poster ? <img src={data.poster} alt={`ملصق ${data.title}`} /> : <div className="poster-fallback"><Film size={40} /></div>}</div>
      <section className="detail-info">
        <span className="detail-overline">{mediaLabel} <span>•</span> T3B اختيار المحررين</span>
        <h1>{data.title}</h1>
        {data.releaseDate && <p className="detail-original-date">تاريخ الإصدار: {data.releaseDate}</p>}
        <div className="detail-facts">
          {data.year && <span><CalendarDays size={15} /> {data.year}</span>}
          {data.rating !== null && <span className="detail-rating"><Star size={15} fill="currentColor" /> {data.rating.toFixed(1)} / 10</span>}
          {data.runtime && <span>{data.runtime} دقيقة</span>}
          {data.seasonCount !== undefined && <span><Tv size={15} /> {data.seasonCount} {data.mediaType === "anime" && !data.id.startsWith("tmdb-") ? "حلقة" : "موسم"}</span>}
        </div>
        <div className="detail-genres">{data.genres.map((genre) => <span key={genre}>{genre}</span>)}</div>
        <h2>عن العمل</h2>
        <p className="detail-overview">{data.overview || "لا يتوفر ملخص لهذا العنوان حاليًا."}</p>
        <div className="detail-actions">
          {data.trailerKey && <a className="button-primary" href={`https://www.youtube.com/watch?v=${encodeURIComponent(data.trailerKey)}`} target="_blank" rel="noreferrer"><Play size={17} fill="currentColor" /> الإعلان الرسمي</a>}
          {data.watchUrl && <a className="button-ghost" href={data.watchUrl} target="_blank" rel="noreferrer"><ExternalLink size={17} /> أماكن المشاهدة الرسمية</a>}
          <button className={saved ? "button-ghost saved-action" : "button-ghost"} onClick={toggleSaved}><Bookmark size={17} /> {saved ? "أُضيف إلى قائمتي" : "أضف إلى قائمتي"}</button>
        </div>
        {data.seasons && data.seasons.length > 0 && <div className="season-panel"><h2>المواسم</h2><div>{data.seasons.map((season, index) => <span key={`${season.name}-${index}`}>{season.name}<small>{season.episodeCount ? `${season.episodeCount} حلقة` : ""}</small></span>)}</div></div>}
        <p className="legal-note">تُعرض معلومات العنوان والإعلان وروابط الوصول إلى مزودي المشاهدة الرسميين. لا يستضيف T3B TV ملفات الأفلام أو الحلقات.</p>
      </section>
    </main>
    <footer className="detail-footer"><Link to="/" className="detail-footer-link"><ArrowRight size={16} /> استكشف المزيد</Link><span>الملصقات والبيانات: TMDB • معلومات الأنمي: Jikan</span></footer>
  </div>;
}
